package netmirror.music.iad1tya.utils

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewDatabase
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

fun clearPlaybackWebAuthSession(context: Context) {
  clearWebAuthStorage(context)
  val cookieManager = CookieManager.getInstance()
  cookieManager.removeSessionCookies(null)
  cookieManager.removeAllCookies(null)
  cookieManager.flush()
}

suspend fun clearWebAuthSession(context: Context) {
  withContext(Dispatchers.Main.immediate) {
    clearWebAuthStorage(context)
    val cookieManager = CookieManager.getInstance()
    suspendCancellableCoroutine<Unit> { continuation ->
      cookieManager.removeSessionCookies {
        cookieManager.removeAllCookies {
          cookieManager.flush()
          if (continuation.isActive) {
            continuation.resume(Unit)
          }
        }
      }
    }
  }
}

fun resetAuthWebViewSession(
  context: Context,
  webView: WebView,
  clearCookies: Boolean = true,
  onReady: () -> Unit,
) {
  webView.stopLoading()
  webView.clearHistory()
  webView.clearFormData()
  webView.clearCache(true)
  clearWebAuthStorage(context)

  val cookieManager = CookieManager.getInstance()
  cookieManager.setAcceptCookie(true)
  cookieManager.setAcceptThirdPartyCookies(webView, true)
  if (!clearCookies) {
    onReady()
    return
  }

  cookieManager.removeSessionCookies {
    cookieManager.removeAllCookies {
      cookieManager.flush()
      cookieManager.setAcceptCookie(true)
      cookieManager.setAcceptThirdPartyCookies(webView, true)
      onReady()
    }
  }
}

private fun clearWebAuthStorage(context: Context) {
  val appContext = context.applicationContext
  WebStorage.getInstance().deleteAllData()
  WebViewDatabase.getInstance(appContext).apply {
    clearFormData()
    clearHttpAuthUsernamePassword()
    clearUsernamePassword()
  }
}
