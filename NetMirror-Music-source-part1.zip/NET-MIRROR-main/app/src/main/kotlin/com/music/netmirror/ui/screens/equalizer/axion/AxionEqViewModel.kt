package netmirror.music.iad1tya.ui.screens.equalizer.axion

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import netmirror.music.dsp.controller.DspController
import netmirror.music.dsp.core.models.FilterType
import netmirror.music.dsp.core.models.ParametricEQBand
import netmirror.music.dsp.core.models.SavedEQProfile
import netmirror.music.dsp.data.EQProfileRepository
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class AxionEqViewModel
@Inject
constructor(
  @ApplicationContext private val context: Context,
  private val dspController: DspController,
  private val eqProfileRepository: EQProfileRepository
) : ViewModel() {

  private val prefs = context.getSharedPreferences("echo_eq_prefs", Context.MODE_PRIVATE)

  private val _enabled = MutableStateFlow(prefs.getBoolean("enabled", false))
  val enabled = _enabled.asStateFlow()

  private val bandFrequencies =
    doubleArrayOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)

  private val _bandGains = MutableStateFlow(FloatArray(10) { prefs.getFloat("band_$it", 0f) })
  val bandGains = _bandGains.asStateFlow()

  private val _mode = MutableStateFlow(prefs.getInt("mode", 0))
  val mode = _mode.asStateFlow()

  private val _isDirty = MutableStateFlow(false)
  val isDirty = _isDirty.asStateFlow()

  val customProfiles =
    eqProfileRepository.profiles
      .map { profiles -> profiles.filter { it.isCustom && it.id != "echo_tuning" } }
      .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  init {
    if (_enabled.value) {
      applyToService()
    }
  }

  fun setEnabled(enabled: Boolean) {
    _enabled.value = enabled
    prefs.edit().putBoolean("enabled", enabled).apply()
    if (enabled) {
      applyToService()
    } else {
      viewModelScope.launch { eqProfileRepository.setActiveProfile(null) }
      dspController.disableEqualizer()
    }
  }

  fun setMode(mode: Int) {
    _mode.value = mode
    prefs.edit().putInt("mode", mode).apply()
    _isDirty.value = false
  }

  fun setBandGain(index: Int, gain: Float) {
    val newGains = _bandGains.value.copyOf()
    newGains[index] = gain
    _bandGains.value = newGains
    prefs.edit().putFloat("band_$index", gain).apply()
    _isDirty.value = true
    if (_enabled.value) {
      applyToService()
    }
  }

  fun setBandsGains(gains: FloatArray, fromUser: Boolean = false) {
    _bandGains.value = gains
    val editor = prefs.edit()
    gains.forEachIndexed { index, f -> editor.putFloat("band_$index", f) }
    editor.apply()
    _isDirty.value = fromUser
    if (_enabled.value) {
      applyToService()
    }
  }

  fun reset() {
    val flat = FloatArray(10) { 0f }
    setBandsGains(flat)
  }

  fun saveCustomProfile(name: String) {
    viewModelScope.launch {
      val bands =
        _bandGains.value.mapIndexed { index, f ->
          ParametricEQBand(
            frequency = bandFrequencies[index],
            gain = f.toDouble() / 50.0,
            q = 1.41,
            filterType = FilterType.PK,
            enabled = true
          )
        }

      val id = "custom_${System.currentTimeMillis()}"
      val profile =
        SavedEQProfile(
          id = id,
          name = name,
          deviceModel = "Equalizer",
          bands = bands,
          preamp = 0.0,
          isCustom = true,
          isActive = true
        )

      eqProfileRepository.saveProfile(profile)
      eqProfileRepository.setActiveProfile(profile.id)
      _isDirty.value = false
    }
  }

  fun deleteProfiles(ids: List<String>) {
    viewModelScope.launch { ids.forEach { id -> eqProfileRepository.deleteProfile(id) } }
  }

  private fun applyToService() {
    viewModelScope.launch {
      val bands =
        _bandGains.value.mapIndexed { index, f ->
          ParametricEQBand(
            frequency = bandFrequencies[index],
            gain = f.toDouble() / 50.0,
            q = 1.41,
            filterType = FilterType.PK,
            enabled = true
          )
        }

      val profile =
        SavedEQProfile(
          id = "echo_tuning",
          name = "Echo Tuning",
          deviceModel = "Equalizer",
          bands = bands,
          preamp = 0.0,
          isCustom = false,
          isActive = true
        )

      eqProfileRepository.saveProfile(profile)
      eqProfileRepository.setActiveProfile(profile.id)

      dspController.applyProfile(profile)
    }
  }
}
