/** Metrolist Project (C) 2026 Licensed under GPL-3.0 | See git history for contributors */
package netmirror.music.iad1tya.widget

/**
 * AppWidgetProvider for Design 1: Modern Flow (4x2 card with progress bar, favorites, and library).
 */
class EchoModernWidgetReceiver : MusicWidgetReceiver()
