package netmirror.music.iad1tya.constants

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import java.time.LocalDateTime
import java.time.ZoneOffset

val IsFirstRunKey = booleanPreferencesKey("isFirstRun")
val DataSaverEnabledKey = booleanPreferencesKey("dataSaverEnabled")
val SpotifySpDcKey = stringPreferencesKey("spotify_sp_dc")
val SpotifySpKeyKey = stringPreferencesKey("spotify_sp_key")
val SpotifyAccountNameKey = stringPreferencesKey("spotify_account_name")
val SpotifyAccountAvatarUrlKey = stringPreferencesKey("spotify_account_avatar_url")
val SpotifyAccessTokenKey = stringPreferencesKey("spotify_access_token")
val SpotifyAccessTokenExpiresAtKey = longPreferencesKey("spotify_access_token_expires_at")
val EnableDynamicIconKey = booleanPreferencesKey("enableDynamicIcon")
val EnableLegacyIconKey = booleanPreferencesKey("enableLegacyIcon")
val AppIconTypeKey = stringPreferencesKey("app_icon_type")

val EnableHighRefreshRateKey = booleanPreferencesKey("enableHighRefreshRate")
val EnableHapticsKey = booleanPreferencesKey("enableHaptics")
val HapticIntensityKey = stringPreferencesKey("haptic_intensity")
val EnableClickHapticsKey = booleanPreferencesKey("enable_click_haptics")
val EnableLongPressHapticsKey = booleanPreferencesKey("enable_long_press_haptics")
val EnableScrollEdgeHapticsKey = booleanPreferencesKey("enable_scroll_edge_haptics")
val EnableSliderHapticsKey = booleanPreferencesKey("enable_slider_haptics")

enum class HapticIntensity(val label: String, val scaleFactor: Float) {
  LIGHT("Light", 0.4f),
  MEDIUM("Medium", 0.75f),
  STRONG("Strong", 1.0f);

  companion object {
    fun fromName(name: String?): HapticIntensity =
      entries.find { it.name.equals(name, ignoreCase = true) } ?: MEDIUM
  }
}

val DynamicThemeKey = booleanPreferencesKey("dynamicTheme")
val SelectedThemeColorKey = intPreferencesKey("selectedThemeColor")
val DarkModeKey = stringPreferencesKey("darkMode")
val PureBlackKey = booleanPreferencesKey("pureBlack")
val PureBlackMiniPlayerKey = booleanPreferencesKey("pureBlackMiniPlayer")
val MiniPlayerOutlineKey = booleanPreferencesKey("miniPlayerOutline")
val DensityScaleKey = floatPreferencesKey("density_scale_factor")
val CustomDensityScaleKey = floatPreferencesKey("custom_density_scale_value")

enum class DensityScale(val value: Float, val label: String) {
  NATIVE(1.0f, "Native (100%)"),
  SLIGHTLY_COMPACT(0.85f, "Slightly Compact (85%)"),
  COMPACT(0.75f, "Compact (75%)"),
  VERY_COMPACT(0.65f, "Very Compact (65%)"),
  ULTRA_COMPACT(0.55f, "Ultra Compact (55%)");

  companion object {
    fun fromValue(value: Float): DensityScale = entries.find { it.value == value } ?: NATIVE
  }
}

val DefaultOpenTabKey = stringPreferencesKey("defaultOpenTab")
val SlimNavBarKey = booleanPreferencesKey("slimNavBar")
val GridItemsSizeKey = stringPreferencesKey("gridItemSize")
val SliderStyleKey = stringPreferencesKey("sliderStyle")
val SquigglySliderKey = booleanPreferencesKey("squigglySlider")
val WavyPlayPauseKey = booleanPreferencesKey("wavyPlayPause")
val SwipeToSongKey = booleanPreferencesKey("SwipeToSong")
val SwipeToRemoveSongKey = booleanPreferencesKey("SwipeToRemoveSong")
val UseNewPlayerDesignKey = booleanPreferencesKey("useNewPlayerDesign")
val UseNewMiniPlayerDesignKey = booleanPreferencesKey("useNewMiniPlayerDesign")
val ShowCodecOnPlayerKey = booleanPreferencesKey("showCodecOnPlayer")
val HidePlayerSliderKey = booleanPreferencesKey("hidePlayerSlider")
val HidePlayerThumbnailKey = booleanPreferencesKey("hidePlayerThumbnail")
val ThumbnailCornerRadiusKey = floatPreferencesKey("thumbnailCornerRadius")
val CropAlbumArtKey = booleanPreferencesKey("cropAlbumArt")
val SeekExtraSeconds = booleanPreferencesKey("seekExtraSeconds")
val VarispeedKey = booleanPreferencesKey("varispeed")

val PauseOnMute = booleanPreferencesKey("pauseOnMute")
val ResumeOnBluetoothConnectKey = booleanPreferencesKey("resumeOnBluetoothConnect")
val AutoplayOnAutomotiveConnectKey = booleanPreferencesKey("autoplayOnAutomotiveConnect")
val KeepScreenOn = booleanPreferencesKey("keepScreenOn")
val DeveloperModeKey = booleanPreferencesKey("developerMode")

enum class SliderStyle {
  DEFAULT,
  WAVY,
  SLIM
}

const val SYSTEM_DEFAULT = "SYSTEM_DEFAULT"
val AppLanguageKey = stringPreferencesKey("appLanguage")
val ContentLanguageKey = stringPreferencesKey("contentLanguage")
val ContentCountryKey = stringPreferencesKey("contentCountry")
val SuggestionRegionKey = stringPreferencesKey("suggestionRegion")
val EnableKugouKey = booleanPreferencesKey("enableKugou")
val FetchFasterLyricsKey = booleanPreferencesKey("fetchFasterLyrics")

val EnableLrcLibKey = booleanPreferencesKey("enableLrclib")
val EnableBetterLyricsKey = booleanPreferencesKey("enableBetterLyrics")
val EnableSimpMusicKey = booleanPreferencesKey("enableSimpMusic")
val EnableYouLyPlusKey = booleanPreferencesKey("enableYouLyPlus")
val EnablePaxsenixKey = booleanPreferencesKey("enablePaxsenix")
val HideExplicitKey = booleanPreferencesKey("hideExplicit")
val SponsorBlockEnabledKey = booleanPreferencesKey("sponsor_block_enabled")
val HideVideoSongsKey = booleanPreferencesKey("hideVideoSongs")
val HideYoutubeShortsKey = booleanPreferencesKey("hideYoutubeShorts")
val ShowArtistDescriptionKey = booleanPreferencesKey("showArtistDescription")
val ShowArtistSubscriberCountKey = booleanPreferencesKey("showArtistSubscriberCount")
val ShowMonthlyListenersKey = booleanPreferencesKey("showMonthlyListeners")
val ShowArtistVideoKey = booleanPreferencesKey("showArtistVideo")
val ShowArtistBackgroundVideoKey = booleanPreferencesKey("showArtistBackgroundVideo")
val ProxyEnabledKey = booleanPreferencesKey("proxyEnabled")
val ProxyUrlKey = stringPreferencesKey("proxyUrl")
val ProxyTypeKey = stringPreferencesKey("proxyType")
val ProxyUsernameKey = stringPreferencesKey("proxyUsername")
val ProxyPasswordKey = stringPreferencesKey("proxyPassword")
val YtmSyncKey = booleanPreferencesKey("ytmSync")
val SelectedYtmPlaylistsKey = stringPreferencesKey("selectedYtmPlaylists")

val ShowAudioFallbackToastKey = booleanPreferencesKey("show_audio_fallback_toast")
val AudioQualityKey = stringPreferencesKey("audioQuality")
val AudioQualityWifiKey = stringPreferencesKey("audioQualityWifi")
val AudioQualityCellularKey = stringPreferencesKey("audioQualityCellular")
val IpVersionKey = stringPreferencesKey("ipVersion")

enum class AudioQuality(
  val maxKbps: Int,
  val label: String,
  val detail: String,
  val hourly: String,
) {
  AUTO(Int.MAX_VALUE, "Auto", "Adaptive based on connection", "Variable"),
  LOW(64, "Low", "~64 kbps · data saver", "29 MB/hr"),
  MEDIUM(160, "Medium", "Standard · ~160 kbps Opus", "77 MB/hr"),
  HIGH(320, "High", "Addon high bitrate, YouTube fallback", "144 MB/hr"),
  LOSSLESS(Int.MAX_VALUE, "Lossless", "Addons bit-exact FLAC/ALAC, YouTube fallback", "300+ MB/hr"),
  OPUS(160, "Opus", "Standard ~160 kbps Opus", "77 MB/hr");

  fun permitsLossless(): Boolean = this == LOSSLESS || this == AUTO
  fun permitsHigh(): Boolean = this == LOSSLESS || this == AUTO || this == HIGH
  fun permitsAddons(): Boolean = this == LOSSLESS || this == AUTO || this == HIGH
}

val DownloadQualityKey = stringPreferencesKey("downloadQuality")

enum class DownloadQuality {
  YOUTUBE,
}

val DownloadOnWifiOnlyKey = booleanPreferencesKey("downloadOnWifiOnly")
val DownloadWithMetadataKey = booleanPreferencesKey("downloadWithMetadata")

val AudioOffload = booleanPreferencesKey("enableOffload")

val SpatialAudioKey = booleanPreferencesKey("spatialAudio")

val AudioLoudnessPresetKey = stringPreferencesKey("audioLoudnessPreset")

enum class AudioLoudnessPreset(val gainOffsetMb: Int) {
  QUIET(-600),
  NORMAL(0),
  LOUD(300),
  AGGRESSIVE(700),
}

enum class PlaybackEngine {
  POTOKEN,
  BRAVEPIPE,
  AUTO,
}

val PlaybackEngineKey = stringPreferencesKey("playbackEngine")
val ShowSeekButtonsKey = booleanPreferencesKey("showSeekButtons")
val PersistentQueueKey = booleanPreferencesKey("persistentQueue")
val PersistentShuffleAcrossQueuesKey = booleanPreferencesKey("persistentShuffleAcrossQueues")
val RememberShuffleAndRepeatKey = booleanPreferencesKey("rememberShuffleAndRepeat")
val ShuffleModeKey = booleanPreferencesKey("shuffleMode")
val SkipSilenceKey = booleanPreferencesKey("skipSilence")
val SkipSilenceInstantKey = booleanPreferencesKey("skipSilenceInstant")
val AudioNormalizationKey = booleanPreferencesKey("audioNormalization")
val AutoLoadMoreKey = booleanPreferencesKey("autoLoadMore")
val DisableLoadMoreWhenRepeatAllKey = booleanPreferencesKey("disableLoadMoreWhenRepeatAll")
val AutoDownloadOnLikeKey = booleanPreferencesKey("autoDownloadOnLike")
val SimilarContent = booleanPreferencesKey("similarContent")
val AutoSkipNextOnErrorKey = booleanPreferencesKey("autoSkipNextOnError")
val StopMusicOnTaskClearKey = booleanPreferencesKey("stopMusicOnTaskClear")
val ShufflePlaylistFirstKey = booleanPreferencesKey("shufflePlaylistFirst")
val PreventDuplicateTracksInQueueKey = booleanPreferencesKey("preventDuplicateTracksInQueue")
val CrossfadeEnabledKey = booleanPreferencesKey("crossfadeEnabled")
val CrossfadeDurationKey = floatPreferencesKey("crossfadeDuration")
val CrossfadeGaplessKey = booleanPreferencesKey("crossfadeGapless")
val AutomixCrossfadeKey = booleanPreferencesKey("automixCrossfade")
val AutomixDebugOverlayKey = booleanPreferencesKey("automixDebugOverlay")

val MaxImageCacheSizeKey = intPreferencesKey("maxImageCacheSize")
val MaxSongCacheSizeKey = intPreferencesKey("maxSongCacheSize")
val ExportDirectoryUriKey = stringPreferencesKey("exportDirectoryUri")
val ExportingSongIdsKey = stringPreferencesKey("exportingSongIds")
val ExportedSongIdsKey = stringPreferencesKey("exportedSongIds")
// Comma-separated "songId:percent" pairs, e.g. "abc:42,def:87"
val ExportProgressKey = stringPreferencesKey("exportProgress")
val EnableExportAsMp3Key = booleanPreferencesKey("enableExportAsMp3")

val PauseListenHistoryKey = booleanPreferencesKey("pauseListenHistory")
val PauseSearchHistoryKey = booleanPreferencesKey("pauseSearchHistory")
val DisableScreenshotKey = booleanPreferencesKey("disableScreenshot")

val EnableGoogleCastKey = booleanPreferencesKey("enableGoogleCast")

val ListenTogetherServerUrlKey = stringPreferencesKey("listenTogetherServerUrl")
val ListenTogetherUsernameKey = stringPreferencesKey("listenTogetherUsername")
val EnableListenTogetherKey = booleanPreferencesKey("enableListenTogether")
val ListenTogetherAutoApprovalKey = booleanPreferencesKey("listenTogetherAutoApproval")
val ListenTogetherSyncVolumeKey = booleanPreferencesKey("listenTogetherSyncVolume")
val ListenTogetherSmartResyncKey = booleanPreferencesKey("listenTogetherSmartResync")
val ListenTogetherBlockedUsersKey = stringPreferencesKey("listenTogetherBlockedUsers")
val ListenTogetherInTopBarKey = booleanPreferencesKey("listenTogetherInTopBar")

val ListenTogetherSessionTokenKey = stringPreferencesKey("listenTogetherSessionToken")
val ListenTogetherRoomCodeKey = stringPreferencesKey("listenTogetherRoomCode")
val ListenTogetherUserIdKey = stringPreferencesKey("listenTogetherUserId")
val ListenTogetherIsHostKey = booleanPreferencesKey("listenTogetherIsHost")
val ListenTogetherSessionTimestampKey = longPreferencesKey("listenTogetherSessionTimestamp")

val LastFMSessionKey = stringPreferencesKey("lastfmSession")
val LastFMUsernameKey = stringPreferencesKey("lastfmUsername")
val EnableLastFMScrobblingKey = booleanPreferencesKey("lastfmScrobblingEnable")
val LastFMUseNowPlaying = booleanPreferencesKey("lastfmUseNowPlaying")

val LastFMUseSendLikes = booleanPreferencesKey("lastfmUseSendLikes")

val ScrobbleDelayPercentKey = floatPreferencesKey("scrobbleDelayPercent")
val ScrobbleMinSongDurationKey = intPreferencesKey("scrobbleMinSongDuration")
val ScrobbleDelaySecondsKey = intPreferencesKey("scrobbleDelaySeconds")

val ChipSortTypeKey = stringPreferencesKey("chipSortType")
val SongSortTypeKey = stringPreferencesKey("songSortType")
val SongSortDescendingKey = booleanPreferencesKey("songSortDescending")
val DownloadedSongSortTypeKey = stringPreferencesKey("downloadedSongSortType")
val DownloadedSongSortDescendingKey = booleanPreferencesKey("downloadedSongSortDescending")
val PlaylistSongSortTypeKey = stringPreferencesKey("playlistSongSortType")
val PlaylistSongSortDescendingKey = booleanPreferencesKey("playlistSongSortDescending")
val AutoPlaylistSongSortTypeKey = stringPreferencesKey("autoPlaylistSongSortType")
val AutoPlaylistSongSortDescendingKey = booleanPreferencesKey("autoPlaylistSongSortDescending")
val ArtistSortTypeKey = stringPreferencesKey("artistSortType")
val ArtistSortDescendingKey = booleanPreferencesKey("artistSortDescending")
val AlbumSortTypeKey = stringPreferencesKey("albumSortType")
val AlbumSortDescendingKey = booleanPreferencesKey("albumSortDescending")
val PlaylistSortTypeKey = stringPreferencesKey("playlistSortType")
val PlaylistSortDescendingKey = booleanPreferencesKey("playlistSortDescending")
val AddToPlaylistSortTypeKey = stringPreferencesKey("addToPlaylistSortType")
val AddToPlaylistSortDescendingKey = booleanPreferencesKey("addToPlaylistSortDescending")
val ArtistSongSortTypeKey = stringPreferencesKey("artistSongSortType")
val ArtistSongSortDescendingKey = booleanPreferencesKey("artistSongSortDescending")
val MixSortTypeKey = stringPreferencesKey("mixSortType")
val MixSortDescendingKey = booleanPreferencesKey("albumSortDescending")

val LocalSongsMinDurationSecondsKey = intPreferencesKey("local_songs_min_duration_seconds")
val LocalSongsExcludedFoldersKey = stringSetPreferencesKey("local_songs_excluded_folders")
val LocalSongsIncludedFoldersKey = stringSetPreferencesKey("local_songs_included_folders")
val LocalSongsFolderFilterModeKey = stringPreferencesKey("local_songs_folder_filter_mode")
val LocalStorageDirsKey = stringSetPreferencesKey("local_storage_dirs")
val DiscordTokenKey = stringPreferencesKey("discord_token")
val DiscordRefreshTokenKey = stringPreferencesKey("discord_refresh_token")
val DiscordTokenExpiresAtKey = longPreferencesKey("discord_token_expires_at")
val DiscordNameKey = stringPreferencesKey("discord_name")
val DiscordUsernameKey = stringPreferencesKey("discord_username")
val DiscordAvatarUrlKey = stringPreferencesKey("discord_avatar_url")
val EnableDiscordRPCKey = booleanPreferencesKey("enable_discord_rpc")
val DiscordShowWhenPausedKey = booleanPreferencesKey("discord_show_when_paused")
val DiscordPresenceStatusKey = stringPreferencesKey("discord_presence_status")
val DiscordActivityTypeKey = stringPreferencesKey("discord_activity_type")
val DiscordActivityNameKey = stringPreferencesKey("discord_activity_name")
val DiscordActivityDetailsKey = stringPreferencesKey("discord_activity_details")
val DiscordActivityStateKey = stringPreferencesKey("discord_activity_state")
val DiscordActivityPlatformKey = stringPreferencesKey("discord_activity_platform")
val DiscordLargeImageTypeKey = stringPreferencesKey("discord_large_image_type")
val DiscordLargeImageCustomUrlKey = stringPreferencesKey("discord_large_image_custom_url")

val DiscordSmallImageTypeKey = stringPreferencesKey("discord_small_image_type")
val DiscordSmallImageCustomUrlKey = stringPreferencesKey("discord_small_image_custom_url")
val DiscordActivityButton1EnabledKey = booleanPreferencesKey("discord_activity_button1_enabled")
val DiscordActivityButton1LabelKey = stringPreferencesKey("discord_activity_button1_label")
val DiscordActivityButton1UrlSourceKey = stringPreferencesKey("discord_activity_button1_url_source")
val DiscordActivityButton1CustomUrlKey = stringPreferencesKey("discord_activity_button1_custom_url")
val DiscordActivityButton2EnabledKey = booleanPreferencesKey("discord_activity_button2_enabled")
val DiscordActivityButton2LabelKey = stringPreferencesKey("discord_activity_button2_label")
val DiscordActivityButton2UrlSourceKey = stringPreferencesKey("discord_activity_button2_url_source")
val DiscordActivityButton2CustomUrlKey = stringPreferencesKey("discord_activity_button2_custom_url")
val LocalSongsSortTypeKey = stringPreferencesKey("local_songs_sort_type")
val LocalSongsSortDescendingKey = booleanPreferencesKey("local_songs_sort_descending")

val SongFilterKey = stringPreferencesKey("songFilter")
val ArtistFilterKey = stringPreferencesKey("artistFilter")
val AlbumFilterKey = stringPreferencesKey("albumFilter")

val LastLikeSongSyncKey = longPreferencesKey("last_like_song_sync")
val LastLibSongSyncKey = longPreferencesKey("last_library_song_sync")
val LastAlbumSyncKey = longPreferencesKey("last_album_sync")
val LastArtistSyncKey = longPreferencesKey("last_artist_sync")
val LastPlaylistSyncKey = longPreferencesKey("last_playlist_sync")
val LastFullSyncKey = longPreferencesKey("last_full_sync")

const val SYNC_COOLDOWN = 30 * 60L

val ArtistViewTypeKey = stringPreferencesKey("artistViewType")
val AlbumViewTypeKey = stringPreferencesKey("albumViewType")
val PlaylistViewTypeKey = stringPreferencesKey("playlistViewType")

val PlaylistEditLockKey = booleanPreferencesKey("playlistEditLock")
val QuickPicksKey = stringPreferencesKey("discover")
val PreferredLyricsProviderKey = stringPreferencesKey("lyricsProvider")
val LyricsProviderOrderKey = stringPreferencesKey("lyricsProviderOrder")
val QueueEditLockKey = booleanPreferencesKey("queueEditLockV2")
val RandomizeHomeOrderKey = booleanPreferencesKey("randomizeHomeOrder")
val AlbumCanvasEnabledKey = booleanPreferencesKey("albumCanvasEnabled")

val ShowLikedPlaylistKey = booleanPreferencesKey("show_liked_playlist")
val ShowDownloadedPlaylistKey = booleanPreferencesKey("show_downloaded_playlist")
val ShowExportedPlaylistKey = booleanPreferencesKey("show_exported_playlist")
val ShowTopPlaylistKey = booleanPreferencesKey("show_top_playlist")
val ShowBottomPlaylistKey = booleanPreferencesKey("show_bottom_playlist")
val ShowCachedPlaylistKey = booleanPreferencesKey("show_cached_playlist")
val ShowUploadedPlaylistKey = booleanPreferencesKey("show_uploaded_playlist")
val EnablePlayerSwipeKey = booleanPreferencesKey("enable_player_swipe")
val ShowSpeedDialKey = booleanPreferencesKey("showSpeedDial")
val ShowCommentButtonKey = booleanPreferencesKey("show_comment_button")

val MusicFlowEnabledKey = booleanPreferencesKey("music_flow_enabled")
val MusicFlowAutoplayKey = booleanPreferencesKey("music_flow_autoplay")
val MusicFlowAutoNextKey = booleanPreferencesKey("music_flow_auto_next")
val MusicFlowAnimatedBackgroundKey = booleanPreferencesKey("music_flow_animated_background")
val MusicFlowLyricsKey = booleanPreferencesKey("music_flow_lyrics")
val MusicFlowCellularPrefetchKey = booleanPreferencesKey("music_flow_cellular_prefetch")
val MusicFlowHideRecentKey = booleanPreferencesKey("music_flow_hide_recent")
val PreferExtensionAudioKey = booleanPreferencesKey("prefer_extension_audio")

enum class LibraryViewType {
  LIST,
  GRID,
  ;

  fun toggle() =
    when (this) {
      LIST -> GRID
      GRID -> LIST
    }
}

enum class SongFilter {
  LIBRARY,
  LIKED,
  DOWNLOADED,
  UPLOADED,
  EXPORTED
}

enum class ArtistFilter {
  LIBRARY,
  LIKED
}

enum class AlbumFilter {
  LIBRARY,
  LIKED,
  UPLOADED
}

enum class SongSortType {
  CREATE_DATE,
  NAME,
  ARTIST,
  PLAY_TIME,
}

enum class PlaylistSongSortType {
  CUSTOM,
  CREATE_DATE,
  NAME,
  ARTIST,
  PLAY_TIME,
}

enum class AutoPlaylistSongSortType {
  CREATE_DATE,
  NAME,
  ARTIST,
  PLAY_TIME,
}

enum class ArtistSortType {
  CREATE_DATE,
  NAME,
  SONG_COUNT,
  PLAY_TIME,
}

enum class ArtistSongSortType {
  CREATE_DATE,
  NAME,
  PLAY_TIME,
}

enum class AlbumSortType {
  CREATE_DATE,
  NAME,
  ARTIST,
  YEAR,
  SONG_COUNT,
  LENGTH,
  PLAY_TIME,
}

enum class PlaylistSortType {
  CREATE_DATE,
  NAME,
  SONG_COUNT,
  LAST_UPDATED,
}

enum class MixSortType {
  CREATE_DATE,
  NAME,
  LAST_UPDATED,
}

enum class GridItemSize {
  BIG,
  SMALL,
}

enum class MyTopFilter {
  ALL_TIME,
  DAY,
  WEEK,
  MONTH,
  YEAR,
  ;

  fun toTimeMillis(): Long =
    when (this) {
      DAY -> LocalDateTime.now().minusDays(1).toInstant(ZoneOffset.UTC).toEpochMilli()
      WEEK -> LocalDateTime.now().minusWeeks(1).toInstant(ZoneOffset.UTC).toEpochMilli()
      MONTH -> LocalDateTime.now().minusMonths(1).toInstant(ZoneOffset.UTC).toEpochMilli()
      YEAR -> LocalDateTime.now().minusMonths(12).toInstant(ZoneOffset.UTC).toEpochMilli()
      ALL_TIME -> 0
    }
}

enum class QuickPicks {
  QUICK_PICKS,
  LAST_LISTEN,
}

enum class PreferredLyricsProvider {
  LRCLIB,
  KUGOU,
  BETTER_LYRICS,
  SIMPMUSIC,
  YOULYPLUS,
  PAXSENIX,
  UNISON
}

enum class PlayerButtonsStyle {
  DEFAULT,
  PRIMARY,
  TERTIARY
}

enum class PlayerBackgroundStyle {
  DEFAULT,
  GRADIENT,
  BLUR,
  GLOW_ANIMATED,
  APPLE_MUSIC,
  LIVE_MESH,
  LIQUID_GLASS,
}

val TopSize = stringPreferencesKey("topSize")
val HistoryDuration = floatPreferencesKey("historyDuration")

val PlayerButtonsStyleKey = stringPreferencesKey("player_buttons_style")
val PlayerBackgroundStyleKey = stringPreferencesKey("playerBackgroundStyle")
val MiniPlayerBackgroundStyleKey = stringPreferencesKey("miniPlayerBackgroundStyle")
val ShowLyricsKey = booleanPreferencesKey("showLyrics")
val ShowLyricsOnPlayerKey = booleanPreferencesKey("showLyricsOnPlayer")
val SwipeLyricsKey = booleanPreferencesKey("swipeLyrics")
val EnableLyricsThumbnailPlayPauseKey = booleanPreferencesKey("enableLyricsThumbnailPlayPause")
val LyricsTextPositionKey = stringPreferencesKey("lyricsTextPosition")
val LyricsClickKey = booleanPreferencesKey("lyricsClick")
val LyricsScrollKey = booleanPreferencesKey("lyricsScrollKey")
val LyricsRomanizeJapaneseKey = booleanPreferencesKey("lyricsRomanizeJapanese")
val LyricsRomanizeKoreanKey = booleanPreferencesKey("lyricsRomanizeKorean")
val LyricsRomanizeChineseKey = booleanPreferencesKey("lyricsRomanizeChinese")
val LyricsRomanizeRussianKey = booleanPreferencesKey("lyricsRomanizeRussian")
val LyricsRomanizeUkrainianKey = booleanPreferencesKey("lyricsRomanizeUkrainian")
val LyricsRomanizeSerbianKey = booleanPreferencesKey("lyricsRomanizeSerbian")
val LyricsRomanizeBulgarianKey = booleanPreferencesKey("lyricsRomanizeBulgarian")
val LyricsRomanizeBelarusianKey = booleanPreferencesKey("lyricsRomanizeBelarusian")
val LyricsRomanizeKyrgyzKey = booleanPreferencesKey("lyricsRomanizeKyrgyz")
val LyricsRomanizeMacedonianKey = booleanPreferencesKey("lyricsRomanizeMacedonian")
val LyricsRomanizeHindiKey = booleanPreferencesKey("lyricsRomanizeHindi")
val LyricsRomanizePunjabiKey = booleanPreferencesKey("lyricsRomanizePunjabi")
val LyricsRomanizeAsMainKey = booleanPreferencesKey("lyricsRomanizeAsMain")
val LyricsRomanizeCyrillicByLineKey = booleanPreferencesKey("lyricsRomanizeCyrillicByLine")
val TranslateLyricsKey = booleanPreferencesKey("translateLyrics")
val OpenRouterApiKey = stringPreferencesKey("openRouterApiKey")
val AiProviderKey = stringPreferencesKey("aiProvider")
val OpenRouterBaseUrlKey = stringPreferencesKey("openRouterBaseUrl")
val OpenRouterModelKey = stringPreferencesKey("openRouterModel")
val TranslateModeKey = stringPreferencesKey("translateMode")
val TranslateLanguageKey = stringPreferencesKey("translateLanguage")
val AutoTranslateKey = booleanPreferencesKey("autoTranslate")
val AiRecommendationsKey = booleanPreferencesKey("aiRecommendations")
val LastAiRecommendationUpdateDayKey = longPreferencesKey("lastAiRecommendationUpdateDay")
val CreateFromTasteDailyKey = booleanPreferencesKey("createFromTasteDaily")
val LastCreateFromTasteUpdateDayKey = longPreferencesKey("lastCreateFromTasteUpdateDay")
val DeeplApiKey = stringPreferencesKey("deeplApiKey")
val DeeplFormalityKey = stringPreferencesKey("deeplFormality")
val LyricsGlowEffectKey = booleanPreferencesKey("lyricsGlowEffect")
val AppleMusicLyricsBlurKey = booleanPreferencesKey("appleMusicLyricsBlur")
val LyricsStandardBlurKey = booleanPreferencesKey("lyricsStandardBlur")
val HideStatusBarOnFullscreenKey = booleanPreferencesKey("hideStatusBarOnFullscreen")

val LyricsAnimationStyleKey = stringPreferencesKey("lyricsAnimationStyle")

enum class LyricsAnimationStyle {
  NONE,
  FADE,
  GLOW,
  SLIDE,
  KARAOKE,
  APPLE,
  APPLE_V2,
  netmirror_1,
  LYRICS_V2,
  METRO_LYRICS,
}

val LyricsTextSizeKey = floatPreferencesKey("lyricsTextSize")
val LyricsLineSpacingKey = floatPreferencesKey("lyricsLineSpacing")

val PlayerVolumeKey = floatPreferencesKey("playerVolume")
val RepeatModeKey = intPreferencesKey("repeatMode")

val SearchSourceKey = stringPreferencesKey("searchSource")
val SwipeThumbnailKey = booleanPreferencesKey("swipeThumbnail")
val RotatingThumbnailKey = booleanPreferencesKey("rotatingThumbnail")
val CanvasThumbnailAnimationKey = booleanPreferencesKey("canvasThumbnailAnimation")
val SwipeSensitivityKey = floatPreferencesKey("swipeSensitivity")

enum class SearchSource {
  LOCAL,
  ONLINE,
  ;

  fun toggle() =
    when (this) {
      LOCAL -> ONLINE
      ONLINE -> LOCAL
    }
}

val VisitorDataKey = stringPreferencesKey("visitorData")
val DataSyncIdKey = stringPreferencesKey("dataSyncId")
val InnerTubeCookieKey = stringPreferencesKey("innerTubeCookie")
val AccountNameKey = stringPreferencesKey("accountName")
val AccountEmailKey = stringPreferencesKey("accountEmail")
val AccountChannelHandleKey = stringPreferencesKey("accountChannelHandle")
val UseLoginForBrowse = booleanPreferencesKey("useLoginForBrowse")
val LastOpenedVersionCodeKey = intPreferencesKey("lastOpenedVersionCode")

val LanguageCodeToName =
  mapOf(
    "af" to "Afrikaans",
    "az" to "Azərbaycan",
    "id" to "Bahasa Indonesia",
    "ms" to "Bahasa Malaysia",
    "ca" to "Català",
    "cs" to "Čeština",
    "da" to "Dansk",
    "de" to "Deutsch",
    "et" to "Eesti",
    "en-GB" to "English (UK)",
    "en" to "English (US)",
    "es" to "Español (España)",
    "es-419" to "Español (Latinoamérica)",
    "eu" to "Euskara",
    "fil" to "Filipino",
    "fr" to "Français",
    "fr-CA" to "Français (Canada)",
    "gl" to "Galego",
    "hr" to "Hrvatski",
    "zu" to "IsiZulu",
    "is" to "Íslenska",
    "it" to "Italiano",
    "sw" to "Kiswahili",
    "lt" to "Lietuvių",
    "hu" to "Magyar",
    "nl" to "Nederlands",
    "no" to "Norsk",
    "or" to "Odia",
    "uz" to "O‘zbe",
    "pl" to "Polski",
    "pt-PT" to "Português",
    "pt" to "Português (Brasil)",
    "ro" to "Română",
    "sq" to "Shqip",
    "sk" to "Slovenčina",
    "sl" to "Slovenščina",
    "fi" to "Suomi",
    "sv" to "Svenska",
    "bo" to "Tibetan བོད་སྐད།",
    "vi" to "Tiếng Việt",
    "tr" to "Türkçe",
    "bg" to "Български",
    "ky" to "Кыргызча",
    "kk" to "Қазақ Тілі",
    "mk" to "Македонски",
    "mn" to "Монгол",
    "ru" to "Русский",
    "sr" to "Српски",
    "uk" to "Українська",
    "el" to "Ελληνικά",
    "hy" to "Հայերեն",
    "iw" to "עברית",
    "ur" to "اردو",
    "ar" to "العربية",
    "fa" to "فارسی",
    "ne" to "नेपाली",
    "mr" to "मराठी",
    "hi" to "हिन्दी",
    "bn" to "বাংলা",
    "pa" to "ਪੰਜਾਬੀ",
    "gu" to "ગુજરાતી",
    "ta" to "தமிழ்",
    "te" to "తెలుగు",
    "kn" to "ಕನ್ನಡ",
    "ml" to "മലയാളം",
    "si" to "සිංහල",
    "th" to "ภาษาไทย",
    "lo" to "ລາວ",
    "my" to "ဗမာ",
    "ka" to "ქართული",
    "am" to "አማርኛ",
    "km" to "ខ្មែរ",
    "zh-CN" to "中文 (简体)",
    "zh-TW" to "中文 (繁體)",
    "zh-HK" to "中文 (香港)",
    "ja" to "日本語",
    "ko" to "한국어",
  )

val CountryCodeToName =
  mapOf(
    "DZ" to "Algeria",
    "AR" to "Argentina",
    "AU" to "Australia",
    "AT" to "Austria",
    "AZ" to "Azerbaijan",
    "BH" to "Bahrain",
    "BD" to "Bangladesh",
    "BY" to "Belarus",
    "BE" to "Belgium",
    "BO" to "Bolivia",
    "BA" to "Bosnia and Herzegovina",
    "BR" to "Brazil",
    "BG" to "Bulgaria",
    "KH" to "Cambodia",
    "CA" to "Canada",
    "CL" to "Chile",
    "HK" to "Hong Kong",
    "CO" to "Colombia",
    "CR" to "Costa Rica",
    "HR" to "Croatia",
    "CY" to "Cyprus",
    "CZ" to "Czech Republic",
    "DK" to "Denmark",
    "DO" to "Dominican Republic",
    "EC" to "Ecuador",
    "EG" to "Egypt",
    "SV" to "El Salvador",
    "EE" to "Estonia",
    "FI" to "Finland",
    "FR" to "France",
    "GE" to "Georgia",
    "DE" to "Germany",
    "GH" to "Ghana",
    "GR" to "Greece",
    "GT" to "Guatemala",
    "HN" to "Honduras",
    "HU" to "Hungary",
    "IS" to "Iceland",
    "IN" to "India",
    "ID" to "Indonesia",
    "IQ" to "Iraq",
    "IE" to "Ireland",
    "IL" to "Israel",
    "IT" to "Italy",
    "JM" to "Jamaica",
    "JP" to "Japan",
    "JO" to "Jordan",
    "KZ" to "Kazakhstan",
    "KE" to "Kenya",
    "KR" to "South Korea",
    "KW" to "Kuwait",
    "LA" to "Lao",
    "LV" to "Latvia",
    "LB" to "Lebanon",
    "LY" to "Libya",
    "LI" to "Liechtenstein",
    "LT" to "Lithuania",
    "LU" to "Luxembourg",
    "MK" to "Macedonia",
    "MY" to "Malaysia",
    "MT" to "Malta",
    "MX" to "Mexico",
    "ME" to "Montenegro",
    "MA" to "Morocco",
    "NP" to "Nepal",
    "NL" to "Netherlands",
    "NZ" to "New Zealand",
    "NI" to "Nicaragua",
    "NG" to "Nigeria",
    "NO" to "Norway",
    "OM" to "Oman",
    "PK" to "Pakistan",
    "PA" to "Panama",
    "PG" to "Papua New Guinea",
    "PY" to "Paraguay",
    "PE" to "Peru",
    "PH" to "Philippines",
    "PL" to "Poland",
    "PT" to "Portugal",
    "PR" to "Puerto Rico",
    "QA" to "Qatar",
    "RO" to "Romania",
    "RU" to "Russian Federation",
    "SA" to "Saudi Arabia",
    "SN" to "Senegal",
    "RS" to "Serbia",
    "SG" to "Singapore",
    "SK" to "Slovakia",
    "SI" to "Slovenia",
    "ZA" to "South Africa",
    "ES" to "Spain",
    "LK" to "Sri Lanka",
    "SE" to "Sweden",
    "CH" to "Switzerland",
    "TW" to "Taiwan",
    "TZ" to "Tanzania",
    "TH" to "Thailand",
    "TN" to "Tunisia",
    "TR" to "Turkey",
    "UG" to "Uganda",
    "UA" to "Ukraine",
    "AE" to "United Arab Emirates",
    "GB" to "United Kingdom",
    "US" to "United States",
    "UY" to "Uruguay",
    "VE" to "Venezuela (Bolivarian Republic)",
    "VN" to "Vietnam",
    "YE" to "Yemen",
    "ZW" to "Zimbabwe",
  )

val SuggestionRegionSlugToName =
  mapOf(
    "system" to "System Default",
    "us" to "Global (USA)",
    "in" to "India",
    "gb" to "United Kingdom",
    "ca" to "Canada",
    "au" to "Australia",
    "jp" to "Japan",
    "kr" to "South Korea",
    "de" to "Germany",
    "fr" to "France",
    "br" to "Brazil",
    "mx" to "Mexico",
    "ru" to "Russia",
    "it" to "Italy",
    "es" to "Spain",
    "nl" to "Netherlands",
    "se" to "Sweden",
    "no" to "Norway",
    "dk" to "Denmark",
    "fi" to "Finland",
    "pl" to "Poland",
    "tr" to "Turkey",
    "za" to "South Africa",
    "ng" to "Nigeria",
    "id" to "Indonesia",
    "my" to "Malaysia",
    "ph" to "Philippines",
    "th" to "Thailand",
    "vn" to "Vietnam",
    "tw" to "Taiwan",
    "hk" to "Hong Kong",
    "sg" to "Singapore",
    "ar" to "Argentina",
    "co" to "Colombia",
    "cl" to "Chile",
    "pe" to "Peru",
    "eg" to "Egypt",
    "sa" to "Saudi Arabia",
    "ae" to "United Arab Emirates",
    "il" to "Israel"
  )

val SpatialAudioEnabledKey = booleanPreferencesKey("spatial_audio_enabled")
val SpatialAudioStrengthKey = floatPreferencesKey("spatial_audio_strength")
val CrossfeedEnabledKey = booleanPreferencesKey("crossfeed_enabled")
val BassBoostKey = floatPreferencesKey("bass_boost")
val VirtualizerKey = floatPreferencesKey("virtualizer")
val ListenBrainzEnabledKey = booleanPreferencesKey("listenbrainz_enabled")
val ListenBrainzTokenKey = stringPreferencesKey("listenbrainz_token")
val LrcLibLyricsEnabledKey = booleanPreferencesKey("lrclib_lyrics_enabled")
val KuGouLyricsEnabledKey = booleanPreferencesKey("kugou_lyrics_enabled")
val UnisonLyricsEnabledKey = booleanPreferencesKey("unison_lyrics_enabled")
val YouTubeSubtitleLyricsEnabledKey = booleanPreferencesKey("youtube_subtitle_lyrics_enabled")
val EnableCronetKey = booleanPreferencesKey("enable_cronet_http3")
val ForceOpusKey = booleanPreferencesKey("force_opus_audio")
val PreloadNextSongEnabledKey = booleanPreferencesKey("preload_next_song_enabled")
val PreloadNextSongLimitKey = intPreferencesKey("preload_next_song_limit")
val PreloadLyricsEnabledKey = booleanPreferencesKey("preload_lyrics_enabled")

val LiquidGlassGlobalEnabledKey = booleanPreferencesKey("liquidGlassGlobalEnabled")
val LiquidGlassTextColorKey = intPreferencesKey("liquidGlassTextColor")
val LiquidGlassSurfaceTintColorKey = intPreferencesKey("liquidGlassSurfaceTintColor")
val LiquidGlassSurfaceOpacityKey = floatPreferencesKey("liquidGlassSurfaceOpacity")
val LiquidGlassVibrancyKey = floatPreferencesKey("liquidGlassVibrancy")
val LiquidGlassBlurRadiusKey = floatPreferencesKey("liquidGlassBlurRadius")
val LiquidGlassLensHeightKey = floatPreferencesKey("liquidGlassLensHeight")
val LiquidGlassLensAmountKey = floatPreferencesKey("liquidGlassLensAmount")
val LiquidGlassChromaticAberrationKey = booleanPreferencesKey("liquidGlassChromaticAberration")
val LiquidGlassDepthEffectKey = booleanPreferencesKey("liquidGlassDepthEffect")
val LiquidGlassPlayerEnabledKey = booleanPreferencesKey("liquidGlassPlayerEnabled")
val LiquidGlassMiniPlayerEnabledKey = booleanPreferencesKey("liquidGlassMiniPlayerEnabled")
val LiquidGlassNavBarEnabledKey = booleanPreferencesKey("liquidGlassNavBarEnabled")

val UseFloatingNavBarKey = booleanPreferencesKey("useFloatingNavBar")
val SavedAccountsKey = stringPreferencesKey("savedAccounts")
val LiveBlurDensityKey = floatPreferencesKey("live_blur_density")

// Ambient Mode
val AmbientArtScaleKey = floatPreferencesKey("ambient_art_scale")
val AmbientShowTitleKey = booleanPreferencesKey("ambient_show_title")
val AmbientShowArtistKey = booleanPreferencesKey("ambient_show_artist")
val AmbientShowLyricsKey = booleanPreferencesKey("ambient_show_lyrics")
val AmbientShowArtKey = booleanPreferencesKey("ambient_show_art")
val AmbientFullScreenArtKey = booleanPreferencesKey("ambient_full_screen_art")


val AmbientSpacingKey = floatPreferencesKey("ambient_spacing")

enum class AppFont(val value: String) {
  SYSTEM("system"),
  GOOGLE_SANS("google_sans"),
  SANS_FLEX("sans_flex"),
  OUTFIT("outfit"),
  PLUS_JAKARTA_SANS("plus_jakarta_sans"),
  CUSTOM("custom");

  companion object {
    fun fromValue(value: String): AppFont = entries.find { it.value == value } ?: SYSTEM
  }
}

val SelectedFontKey = stringPreferencesKey("selected_app_font")
val CustomFontPathKey = androidx.datastore.preferences.core.stringPreferencesKey("custom_font_path")
val BlockedArtistsKey =
  androidx.datastore.preferences.core.stringSetPreferencesKey("blockedArtists")

val EnableBitPerfectUsbDacKey = booleanPreferencesKey("enable_bit_perfect_usb_dac")
val UsbDacVolumeModeKey = stringPreferencesKey("usb_dac_volume_mode")

enum class RecommendationSource {
    YOUTUBE,
    SPOTIFY
}

val RecommendationSourceKey = stringPreferencesKey("recommendation_source")
