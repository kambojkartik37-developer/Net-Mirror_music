package netmirror.music.iad1tya.extensions

import android.net.Uri
import android.os.Bundle
import androidx.core.net.toUri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata.MEDIA_TYPE_MUSIC
import com.music.innertube.models.SongItem
import netmirror.music.iad1tya.db.entities.Song
import netmirror.music.iad1tya.models.MediaMetadata
import netmirror.music.iad1tya.models.toMediaMetadata
import netmirror.music.iad1tya.ui.utils.resize
import java.util.Locale

val MediaItem.metadata: MediaMetadata?
  get() =
    (localConfiguration?.tag as? MediaMetadata)
      ?: run {
        val meta = mediaMetadata
        val titleStr = (meta.title ?: meta.displayTitle)?.toString()
        if (!titleStr.isNullOrBlank() || mediaId.isNotBlank()) {
          MediaMetadata(
            id = mediaId,
            title = titleStr.orEmpty(),
            artists =
              listOfNotNull(
                meta.artist
                  ?.toString()
                  ?.takeIf { it.isNotBlank() }
                  ?.let { MediaMetadata.Artist(id = null, name = it) }
              ),
            duration = 0,
            thumbnailUrl = meta.artworkUri?.toString() ?: meta.extras?.getString("artwork_uri")
          )
        } else null
      }

private fun playbackSeedUri(mediaId: String): String {
  val scheme = mediaId.toUri().scheme?.lowercase(Locale.US)
  return when (scheme) {
    "content",
    "file",
    "android.resource",
    "http",
    "https" -> mediaId
    else -> "https://music.youtube.com/watch?v=${Uri.encode(mediaId)}"
  }
}

fun Song.toMediaItem() =
  MediaItem.Builder()
    .setMediaId(song.id)
    .setUri(playbackSeedUri(song.id))
    .setCustomCacheKey(song.id)
    .setTag(toMediaMetadata())
    .setMediaMetadata(
      androidx.media3.common.MediaMetadata.Builder()
        .setTitle(song.title)
        .setSubtitle(artists.joinToString { it.name })
        .setArtist(artists.joinToString { it.name })
        .setArtworkUri(song.thumbnailUrl?.toUri())
        .setAlbumTitle(song.albumName)
        .setAlbumArtist(artists.firstOrNull()?.name)
        .setDisplayTitle(song.title)
        .setMediaType(MEDIA_TYPE_MUSIC)
        .setIsBrowsable(false)
        .setIsPlayable(true)
        .setExtras(Bundle().apply { putString("artwork_uri", song.thumbnailUrl) })
        .build()
    )
    .build()

fun SongItem.toMediaItem() =
  MediaItem.Builder()
    .setMediaId(id)
    .setUri(playbackSeedUri(id))
    .setCustomCacheKey(id)
    .setTag(toMediaMetadata())
    .setMediaMetadata(
      androidx.media3.common.MediaMetadata.Builder()
        .setTitle(title)
        .setSubtitle(artists.joinToString { it.name })
        .setArtist(artists.joinToString { it.name })
        .setArtworkUri(thumbnail.resize(1200, 1200).toUri())
        .setAlbumTitle(album?.name)
        .setAlbumArtist(artists.firstOrNull()?.name)
        .setDisplayTitle(title)
        .setMediaType(MEDIA_TYPE_MUSIC)
        .setIsBrowsable(false)
        .setIsPlayable(true)
        .setExtras(Bundle().apply { putString("artwork_uri", thumbnail.resize(1200, 1200)) })
        .build()
    )
    .build()

fun MediaMetadata.toMediaItem() =
  MediaItem.Builder()
    .setMediaId(id)
    .setUri(playbackSeedUri(id))
    .setCustomCacheKey(id)
    .setTag(this)
    .setMediaMetadata(
      androidx.media3.common.MediaMetadata.Builder()
        .setTitle(title)
        .setSubtitle(artists.joinToString { it.name })
        .setArtist(artists.joinToString { it.name })
        .setArtworkUri(thumbnailUrl?.toUri())
        .setAlbumTitle(album?.title)
        .setAlbumArtist(artists.firstOrNull()?.name)
        .setDisplayTitle(title)
        .setMediaType(MEDIA_TYPE_MUSIC)
        .setIsBrowsable(false)
        .setIsPlayable(true)
        .setExtras(Bundle().apply { thumbnailUrl?.let { putString("artwork_uri", it) } })
        .build()
    )
    .build()
