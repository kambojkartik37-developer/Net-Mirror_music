package netmirror.music.iad1tya.playback.queues

import androidx.media3.common.MediaItem
import netmirror.music.iad1tya.models.MediaMetadata

object EmptyQueue : Queue {
  override val preloadItem: MediaMetadata? = null

  override suspend fun getInitialStatus() = Queue.Status(null, emptyList(), -1)

  override fun hasNextPage() = false

  override suspend fun nextPage() = emptyList<MediaItem>()
}
