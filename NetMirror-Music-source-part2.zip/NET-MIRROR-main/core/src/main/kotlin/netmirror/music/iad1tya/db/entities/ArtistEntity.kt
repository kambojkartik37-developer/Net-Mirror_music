package netmirror.music.iad1tya.db.entities

import androidx.compose.runtime.Immutable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.music.innertube.YouTube
import java.time.LocalDateTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.apache.commons.lang3.RandomStringUtils

@Immutable
@Entity(tableName = "artist")
data class ArtistEntity(
  @PrimaryKey val id: String,
  val name: String,
  val thumbnailUrl: String? = null,
  val channelId: String? = null,
  val lastUpdateTime: LocalDateTime = LocalDateTime.now(),
  val bookmarkedAt: LocalDateTime? = null,
  @ColumnInfo(name = "isLocal", defaultValue = false.toString()) val isLocal: Boolean = false
) {
  val isYouTubeArtist: Boolean
    get() = id.startsWith("UC") || id.startsWith("FEmusic_library_privately_owned_artist")

  val isPrivatelyOwnedArtist: Boolean
    get() = id.startsWith("FEmusic_library_privately_owned_artist")

  fun localToggleLike() =
    copy(
      bookmarkedAt = if (bookmarkedAt != null) null else LocalDateTime.now(),
    )

  fun toggleLike() =
    localToggleLike().also {
      CoroutineScope(Dispatchers.IO).launch {
        val targetChannelId = channelId ?: YouTube.getChannelId(id)
        if (targetChannelId.isNotEmpty()) {
          YouTube.subscribeChannel(targetChannelId, bookmarkedAt == null)
        }
      }
    }

  companion object {
    fun generateArtistId() = "LA" + RandomStringUtils.insecure().next(8, true, false)
  }
}
