package netmirror.music.iad1tya.db.entities

import androidx.compose.runtime.Immutable
import androidx.room.Entity

@Immutable
@Entity(tableName = "playCount", primaryKeys = ["song", "year", "month"])
class PlayCountEntity(
  val song: String,
  val year: Int = -1,
  val month: Int = -1,
  val count: Int = -1,
)
