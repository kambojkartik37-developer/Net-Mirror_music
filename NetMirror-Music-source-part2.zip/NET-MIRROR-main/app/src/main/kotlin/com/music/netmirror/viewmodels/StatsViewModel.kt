package netmirror.music.iad1tya.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.music.innertube.YouTube
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import netmirror.music.iad1tya.constants.HideVideoSongsKey
import netmirror.music.iad1tya.constants.statToPeriod
import netmirror.music.iad1tya.db.MusicDatabase
import netmirror.music.iad1tya.ui.screens.OptionStats
import netmirror.music.iad1tya.utils.dataStore
import netmirror.music.iad1tya.utils.reportException
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneOffset
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class StatsViewModel
@Inject
constructor(
  @ApplicationContext private val context: Context,
  val database: MusicDatabase,
) : ViewModel() {
  val selectedOption = MutableStateFlow(OptionStats.CONTINUOUS)
  val indexChips = MutableStateFlow(0)

  val totalPlayTime =
    combine(
        selectedOption,
        indexChips,
      ) { selection, t ->
        Pair(selection, t)
      }
      .flatMapLatest { (selection, t) ->
        val fromTimeStamp = statToPeriod(selection, t)
        val toTimeStamp =
          if (selection == OptionStats.CONTINUOUS || t == 0) {
            LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli()
          } else {
            statToPeriod(selection, t - 1)
          }
        database.getTotalPlayTimeInRange(fromTimeStamp, toTimeStamp)
      }
      .map { it ?: 0L }
      .stateIn(viewModelScope, SharingStarted.Lazily, 0L)

  val allTimePlayTime =
    database
      .getTotalPlayTimeInRange(0, Long.MAX_VALUE)
      .map { it ?: 0L }
      .stateIn(viewModelScope, SharingStarted.Lazily, 0L)

  val uniqueSongsCount =
    combine(
        selectedOption,
        indexChips,
      ) { selection, t ->
        Pair(selection, t)
      }
      .flatMapLatest { (selection, t) ->
        val fromTimeStamp = statToPeriod(selection, t)
        val toTimeStamp =
          if (selection == OptionStats.CONTINUOUS || t == 0) {
            LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli()
          } else {
            statToPeriod(selection, t - 1)
          }
        database.getUniqueSongCountInRange(fromTimeStamp, toTimeStamp)
      }
      .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  val uniqueArtistsCount =
    combine(
        selectedOption,
        indexChips,
      ) { selection, t ->
        Pair(selection, t)
      }
      .flatMapLatest { (selection, t) ->
        val fromTimeStamp = statToPeriod(selection, t)
        val toTimeStamp =
          if (selection == OptionStats.CONTINUOUS || t == 0) {
            LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli()
          } else {
            statToPeriod(selection, t - 1)
          }
        database.getUniqueArtistCountInRange(fromTimeStamp, toTimeStamp)
      }
      .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  val uniqueAlbumsCount =
    combine(
        selectedOption,
        indexChips,
      ) { selection, t ->
        Pair(selection, t)
      }
      .flatMapLatest { (selection, t) ->
        val fromTimeStamp = statToPeriod(selection, t)
        val toTimeStamp =
          if (selection == OptionStats.CONTINUOUS || t == 0) {
            LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli()
          } else {
            statToPeriod(selection, t - 1)
          }
        database.getUniqueAlbumCountInRange(fromTimeStamp, toTimeStamp)
      }
      .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  val allTimeSongsCount =
    database
      .getUniqueSongCountInRange(0, Long.MAX_VALUE)
      .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  val allTimeArtistsCount =
    database
      .getUniqueArtistCountInRange(0, Long.MAX_VALUE)
      .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  val allTimeAlbumsCount =
    database
      .getUniqueAlbumCountInRange(0, Long.MAX_VALUE)
      .stateIn(viewModelScope, SharingStarted.Lazily, 0)

  val mostPlayedSongsStats =
    combine(
        selectedOption,
        indexChips,
        context.dataStore.data
          .map {
            (try {
              it[HideVideoSongsKey]
            } catch (e: Exception) {
              null
            }) ?: false
          }
          .distinctUntilChanged()
      ) { first, second, third ->
        Triple(first, second, third)
      }
      .flatMapLatest { (selection, t, hideVideoSongs) ->
        database
          .mostPlayedSongsStats(
            fromTimeStamp = statToPeriod(selection, t),
            limit = -1,
            toTimeStamp =
              if (selection == OptionStats.CONTINUOUS || t == 0) {
                LocalDateTime.now()
                  .toInstant(
                    ZoneOffset.UTC,
                  )
                  .toEpochMilli()
              } else {
                statToPeriod(selection, t - 1)
              },
          )
          .map { songs -> if (hideVideoSongs) songs.filter { !it.isVideo } else songs }
      }
      .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val mostPlayedSongs =
    combine(
        selectedOption,
        indexChips,
        context.dataStore.data
          .map {
            (try {
              it[HideVideoSongsKey]
            } catch (e: Exception) {
              null
            }) ?: false
          }
          .distinctUntilChanged()
      ) { first, second, third ->
        Triple(first, second, third)
      }
      .flatMapLatest { (selection, t, hideVideoSongs) ->
        database
          .mostPlayedSongs(
            fromTimeStamp = statToPeriod(selection, t),
            limit = -1,
            toTimeStamp =
              if (selection == OptionStats.CONTINUOUS || t == 0) {
                LocalDateTime.now()
                  .toInstant(
                    ZoneOffset.UTC,
                  )
                  .toEpochMilli()
              } else {
                statToPeriod(selection, t - 1)
              },
          )
          .map { songs -> if (hideVideoSongs) songs.filter { !it.song.isVideo } else songs }
      }
      .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val mostPlayedArtists =
    combine(
        selectedOption,
        indexChips,
      ) { first, second ->
        Pair(first, second)
      }
      .flatMapLatest { (selection, t) ->
        database
          .mostPlayedArtists(
            statToPeriod(selection, t),
            limit = -1,
            toTimeStamp =
              if (selection == OptionStats.CONTINUOUS || t == 0) {
                LocalDateTime.now()
                  .toInstant(
                    ZoneOffset.UTC,
                  )
                  .toEpochMilli()
              } else {
                statToPeriod(selection, t - 1)
              },
          )
          .map { artists -> artists.filter { it.artist.isYouTubeArtist } }
      }
      .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val mostPlayedAlbums =
    combine(
        selectedOption,
        indexChips,
      ) { first, second ->
        Pair(first, second)
      }
      .flatMapLatest { (selection, t) ->
        database.mostPlayedAlbums(
          statToPeriod(selection, t),
          limit = -1,
          toTimeStamp =
            if (selection == OptionStats.CONTINUOUS || t == 0) {
              LocalDateTime.now()
                .toInstant(
                  ZoneOffset.UTC,
                )
                .toEpochMilli()
            } else {
              statToPeriod(selection, t - 1)
            },
        )
      }
      .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val firstEvent = database.firstEvent().stateIn(viewModelScope, SharingStarted.Lazily, null)

  init {
    viewModelScope.launch {
      mostPlayedArtists.collect { artists ->
        artists
          .map { it.artist }
          .filter {
            it.thumbnailUrl == null ||
              Duration.between(it.lastUpdateTime, LocalDateTime.now()) > Duration.ofDays(10)
          }
          .forEach { artist ->
            YouTube.artist(artist.id).onSuccess { artistPage ->
              database.query { update(artist, artistPage) }
            }
          }
      }
    }
    viewModelScope.launch {
      mostPlayedAlbums.collect { albums ->
        albums
          .filter { it.album.songCount == 0 }
          .forEach { album ->
            YouTube.album(album.id)
              .onSuccess { albumPage ->
                database.query { update(album.album, albumPage, album.artists) }
              }
              .onFailure {
                reportException(it)
                if (it.message?.contains("NOT_FOUND") == true) {
                  database.query { delete(album.album) }
                }
              }
          }
      }
    }
  }
}
