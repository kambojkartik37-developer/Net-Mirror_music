package netmirror.music.iad1tya.ui.menu

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import androidx.navigation.NavController
import com.music.innertube.YouTube
import com.music.innertube.models.AlbumItem
import netmirror.music.iad1tya.LocalDatabase
import netmirror.music.iad1tya.LocalDownloadUtil
import netmirror.music.iad1tya.LocalListenTogetherManager
import netmirror.music.iad1tya.LocalPlayerConnection
import netmirror.music.iad1tya.R
import netmirror.music.iad1tya.constants.ListItemHeight
import netmirror.music.iad1tya.constants.ListThumbnailSize
import netmirror.music.iad1tya.db.entities.Song
import netmirror.music.iad1tya.db.entities.SpeedDialItem
import netmirror.music.iad1tya.extensions.toMediaItem
import netmirror.music.iad1tya.playback.ExoDownloadService
import netmirror.music.iad1tya.playback.queues.YouTubeAlbumRadio
import netmirror.music.iad1tya.ui.component.ListDialog
import netmirror.music.iad1tya.ui.component.Material3MenuGroup
import netmirror.music.iad1tya.ui.component.Material3MenuItemData
import netmirror.music.iad1tya.ui.component.NewAction
import netmirror.music.iad1tya.ui.component.NewActionGrid
import netmirror.music.iad1tya.ui.component.SongListItem
import netmirror.music.iad1tya.ui.component.YouTubeListItem
import netmirror.music.iad1tya.utils.reportException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("MutableCollectionMutableState")
@Composable
fun YouTubeAlbumMenu(
  albumItem: AlbumItem,
  navController: NavController,
  onDismiss: () -> Unit,
) {
  val context = LocalContext.current
  val database = LocalDatabase.current
  val downloadUtil = LocalDownloadUtil.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val listenTogetherManager = LocalListenTogetherManager.current
  val isGuest = listenTogetherManager?.isGuestPlaybackRestricted == true
  val album by database.albumWithSongs(albumItem.id).collectAsState(initial = null)
  val isPinned by database.speedDialDao.isPinned(albumItem.id).collectAsState(initial = false)
  val coroutineScope = rememberCoroutineScope()

  LaunchedEffect(Unit) {
    database.album(albumItem.id).collect { album ->
      if (album == null) {
        YouTube.album(albumItem.id)
          .onSuccess { albumPage -> database.transaction { insert(albumPage) } }
          .onFailure { reportException(it) }
      }
    }
  }

  var downloadState by remember { mutableIntStateOf(Download.STATE_STOPPED) }

  LaunchedEffect(album) {
    val songs = album?.songs?.map { it.id } ?: return@LaunchedEffect
    downloadUtil.downloads.collect { downloads ->
      downloadState =
        if (songs.all { downloads[it]?.state == Download.STATE_COMPLETED }) {
          Download.STATE_COMPLETED
        } else if (
          songs.all {
            downloads[it]?.state == Download.STATE_QUEUED ||
              downloads[it]?.state == Download.STATE_DOWNLOADING ||
              downloads[it]?.state == Download.STATE_COMPLETED
          }
        ) {
          Download.STATE_DOWNLOADING
        } else {
          Download.STATE_STOPPED
        }
    }
  }

  var showChoosePlaylistDialog by rememberSaveable { mutableStateOf(false) }

  var showErrorPlaylistAddDialog by rememberSaveable { mutableStateOf(false) }

  val notAddedList by remember { mutableStateOf(mutableListOf<Song>()) }

  AddToPlaylistDialog(
    isVisible = showChoosePlaylistDialog,
    onGetSong = { playlist ->
      coroutineScope.launch(Dispatchers.IO) {
        playlist.playlist.browseId?.let { playlistId ->
          album?.album?.playlistId?.let { addPlaylistId ->
            YouTube.addPlaylistToPlaylist(playlistId, addPlaylistId)
          }
        }
      }
      album?.songs?.map { it.id }.orEmpty()
    },
    onDismiss = { showChoosePlaylistDialog = false }
  )

  if (showErrorPlaylistAddDialog) {
    ListDialog(
      onDismiss = {
        showErrorPlaylistAddDialog = false
        onDismiss()
      },
    ) {
      item {
        ListItem(
          headlineContent = { Text(text = stringResource(R.string.already_in_playlist)) },
          leadingContent = {
            Image(
              painter = painterResource(R.drawable.close),
              contentDescription = null,
              colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onBackground),
              modifier = Modifier.size(ListThumbnailSize),
            )
          },
          modifier = Modifier.clickable { showErrorPlaylistAddDialog = false },
        )
      }

      items(notAddedList) { song -> SongListItem(song = song) }
    }
  }

  var showSelectArtistDialog by rememberSaveable { mutableStateOf(false) }

  if (showSelectArtistDialog) {
    ListDialog(
      onDismiss = { showSelectArtistDialog = false },
    ) {
      items(
        items = album?.artists.orEmpty().distinctBy { it.id },
        key = { it.id },
      ) { artist ->
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier =
            Modifier.height(ListItemHeight)
              .clickable {
                navController.navigate("artist/${artist.id}")
                showSelectArtistDialog = false
                onDismiss()
              }
              .padding(horizontal = 12.dp),
        ) {
          Box(
            contentAlignment = Alignment.CenterStart,
            modifier =
              Modifier.fillParentMaxWidth()
                .height(ListItemHeight)
                .clickable {
                  showSelectArtistDialog = false
                  onDismiss()
                  navController.navigate("artist/${artist.id}")
                }
                .padding(horizontal = 24.dp),
          ) {
            Text(
              text = artist.name,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }

  YouTubeListItem(
    item = albumItem,
    shape = MaterialTheme.shapes.large,
    color = androidx.compose.ui.graphics.Color.Transparent,
    badges = {},
    trailingContent = {
      IconButton(
        onClick = { database.query { album?.album?.toggleLike()?.let(::update) } },
      ) {
        Icon(
          painter =
            painterResource(
              if (album?.album?.bookmarkedAt != null) R.drawable.favorite
              else R.drawable.favorite_border
            ),
          tint =
            if (album?.album?.bookmarkedAt != null) MaterialTheme.colorScheme.error
            else LocalContentColor.current,
          contentDescription = null,
        )
      }
    },
  )

  HorizontalDivider()

  Spacer(modifier = Modifier.height(12.dp))

  val configuration = LocalConfiguration.current
  val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT

  LazyColumn(
    contentPadding =
      PaddingValues(
        start = 0.dp,
        top = 0.dp,
        end = 0.dp,
        bottom = 8.dp + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding(),
      ),
  ) {
    item {
      NewActionGrid(
        actions =
          listOfNotNull(
            if (!isGuest) {
              NewAction(
                icon = {
                  Icon(
                    painter = painterResource(R.drawable.play),
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                },
                text = stringResource(R.string.play),
                onClick = {
                  onDismiss()
                  album?.songs?.let { songs ->
                    if (songs.isNotEmpty()) {
                      playerConnection.playQueue(YouTubeAlbumRadio(albumItem.playlistId))
                    }
                  }
                }
              )
              NewAction(
                icon = {
                  Icon(
                    painter = painterResource(R.drawable.shuffle),
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                },
                text = stringResource(R.string.shuffle),
                onClick = {
                  onDismiss()
                  album?.songs?.let { songs ->
                    if (songs.isNotEmpty()) {
                      playerConnection.playQueue(YouTubeAlbumRadio(albumItem.playlistId))
                    }
                  }
                }
              )
            } else null,
            NewAction(
              icon = {
                Icon(
                  painter = painterResource(R.drawable.share),
                  contentDescription = null,
                  modifier = Modifier.size(28.dp),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              },
              text = stringResource(R.string.share),
              onClick = {
                onDismiss()
                val intent =
                  Intent().apply {
                    action = Intent.ACTION_SEND
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, albumItem.shareLink)
                  }
                context.startActivity(Intent.createChooser(intent, null))
              }
            )
          ),
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 16.dp),
        columns = if (isGuest) 1 else 3
      )
    }
    item {
      Material3MenuGroup(
        items =
          listOfNotNull(
            if (!isGuest) {
              Material3MenuItemData(
                title = { Text(text = stringResource(R.string.play_next)) },
                description = { Text(text = stringResource(R.string.play_next_desc)) },
                icon = {
                  Icon(
                    painter = painterResource(R.drawable.playlist_play),
                    contentDescription = null,
                  )
                },
                onClick = {
                  album?.songs?.map { it.toMediaItem() }?.let(playerConnection::playNext)
                  onDismiss()
                }
              )
            } else null,
            if (!isGuest) {
              Material3MenuItemData(
                title = { Text(text = stringResource(R.string.add_to_queue)) },
                description = { Text(text = stringResource(R.string.add_to_queue_desc)) },
                icon = {
                  Icon(
                    painter = painterResource(R.drawable.queue_music),
                    contentDescription = null,
                  )
                },
                onClick = {
                  album?.songs?.map { it.toMediaItem() }?.let(playerConnection::addToQueue)
                  onDismiss()
                }
              )
            } else null,
            Material3MenuItemData(
              title = { Text(text = stringResource(R.string.add_to_playlist)) },
              description = { Text(text = stringResource(R.string.add_to_playlist_desc)) },
              icon = {
                Icon(
                  painter = painterResource(R.drawable.playlist_add),
                  contentDescription = null,
                )
              },
              onClick = { showChoosePlaylistDialog = true }
            ),
            Material3MenuItemData(
              title = {
                Text(text = if (isPinned) "Unpin from Speed dial" else "Pin to Speed dial")
              },
              icon = {
                Icon(
                  painter = painterResource(if (isPinned) R.drawable.remove else R.drawable.add),
                  contentDescription = null,
                )
              },
              onClick = {
                coroutineScope.launch(Dispatchers.IO) {
                  if (isPinned) {
                    database.speedDialDao.delete(albumItem.id)
                  } else {
                    database.speedDialDao.insert(SpeedDialItem.fromYTItem(albumItem))
                  }
                }
                onDismiss()
              }
            )
          )
      )
    }

    item { Spacer(modifier = Modifier.height(12.dp)) }

    item {
      Material3MenuGroup(
        items =
          listOf(
            when (downloadState) {
              Download.STATE_COMPLETED -> {
                Material3MenuItemData(
                  title = { Text(text = stringResource(R.string.remove_download)) },
                  icon = {
                    Icon(painter = painterResource(R.drawable.offline), contentDescription = null)
                  },
                  onClick = {
                    album?.songs?.forEach { song ->
                      DownloadService.sendRemoveDownload(
                        context,
                        ExoDownloadService::class.java,
                        song.id,
                        false,
                      )
                    }
                  }
                )
              }
              Download.STATE_QUEUED,
              Download.STATE_DOWNLOADING -> {
                Material3MenuItemData(
                  title = { Text(text = stringResource(R.string.downloading)) },
                  icon = {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                  },
                  onClick = {
                    album?.songs?.forEach { song ->
                      DownloadService.sendRemoveDownload(
                        context,
                        ExoDownloadService::class.java,
                        song.id,
                        false,
                      )
                    }
                  }
                )
              }
              else -> {
                Material3MenuItemData(
                  title = { Text(text = stringResource(R.string.action_download)) },
                  description = { Text(text = stringResource(R.string.download_desc)) },
                  icon = {
                    Icon(
                      painter = painterResource(R.drawable.download),
                      contentDescription = null,
                    )
                  },
                  onClick = {
                    album?.songs?.forEach { song ->
                      val downloadRequest =
                        DownloadRequest.Builder(song.id, song.id.toUri())
                          .setCustomCacheKey(song.id)
                          .setData(song.song.title.toByteArray())
                          .build()
                      DownloadService.sendAddDownload(
                        context,
                        ExoDownloadService::class.java,
                        downloadRequest,
                        false,
                      )
                    }
                  }
                )
              }
            }
          )
      )
    }

    albumItem.artists?.let { artists ->
      item { Spacer(modifier = Modifier.height(12.dp)) }
      item {
        Material3MenuGroup(
          items =
            listOf(
              Material3MenuItemData(
                title = { Text(text = stringResource(R.string.view_artist)) },
                description = { Text(text = artists.joinToString { it.name }) },
                icon = {
                  Icon(
                    painter = painterResource(R.drawable.artist),
                    contentDescription = null,
                  )
                },
                onClick = {
                  if (artists.size == 1) {
                    navController.navigate("artist/${artists[0].id}")
                    onDismiss()
                  } else {
                    showSelectArtistDialog = true
                  }
                }
              )
            )
        )
      }
    }
  }
}
