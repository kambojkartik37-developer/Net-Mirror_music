package netmirror.music.iad1tya.utils

import android.content.Context
import android.content.res.Configuration
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.util.Locale
import racra.compose.smooth_corner_rect_library.AbsoluteSmoothCornerShape

@Suppress("DEPRECATION")
fun setAppLocale(context: Context, locale: Locale) {
  val config = Configuration(context.resources.configuration)
  config.setLocale(locale)
  context.resources.updateConfiguration(config, context.resources.displayMetrics)
}

fun listItemShape(index: Int, count: Int, radius: Dp = 24.dp): Shape {
  val smoothness = 60
  return when {
    count == 1 ->
      AbsoluteSmoothCornerShape(
        cornerRadiusTL = radius,
        smoothnessAsPercentTL = smoothness,
        cornerRadiusTR = radius,
        smoothnessAsPercentTR = smoothness,
        cornerRadiusBL = radius,
        smoothnessAsPercentBL = smoothness,
        cornerRadiusBR = radius,
        smoothnessAsPercentBR = smoothness
      )
    index == 0 ->
      AbsoluteSmoothCornerShape(
        cornerRadiusTL = radius,
        smoothnessAsPercentTL = smoothness,
        cornerRadiusTR = radius,
        smoothnessAsPercentTR = smoothness,
        cornerRadiusBL = 0.dp,
        smoothnessAsPercentBL = 0,
        cornerRadiusBR = 0.dp,
        smoothnessAsPercentBR = 0
      )
    index == count - 1 ->
      AbsoluteSmoothCornerShape(
        cornerRadiusTL = 0.dp,
        smoothnessAsPercentTL = 0,
        cornerRadiusTR = 0.dp,
        smoothnessAsPercentTR = 0,
        cornerRadiusBL = radius,
        smoothnessAsPercentBL = smoothness,
        cornerRadiusBR = radius,
        smoothnessAsPercentBR = smoothness
      )
    else -> RectangleShape
  }
}
