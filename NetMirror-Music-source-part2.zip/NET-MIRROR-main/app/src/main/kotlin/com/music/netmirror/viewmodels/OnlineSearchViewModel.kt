package netmirror.music.iad1tya.viewmodels

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.music.innertube.YouTube
import com.music.innertube.models.filterExplicit
import com.music.innertube.models.filterVideoSongs
import com.music.innertube.models.filterYoutubeShorts
import com.music.innertube.pages.SearchSummaryPage
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import netmirror.music.iad1tya.constants.HideExplicitKey
import netmirror.music.iad1tya.constants.HideVideoSongsKey
import netmirror.music.iad1tya.constants.HideYoutubeShortsKey
import netmirror.music.iad1tya.models.ItemsPage
import netmirror.music.iad1tya.utils.dataStore
import netmirror.music.iad1tya.utils.get
import netmirror.music.iad1tya.utils.reportException
import java.net.URLDecoder
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class OnlineSearchViewModel
@Inject
constructor(
  @ApplicationContext val context: Context,
  savedStateHandle: SavedStateHandle,
  val extensionManager: com.music.netmirror.extensions.ExtensionManager,
) : ViewModel() {
  val query =
    try {
      URLDecoder.decode(savedStateHandle.get<String>("query")!!, "UTF-8")
    } catch (e: IllegalArgumentException) {
      savedStateHandle.get<String>("query")!!
    }
  val filter = MutableStateFlow<YouTube.SearchFilter?>(null)
  var summaryPage by mutableStateOf<SearchSummaryPage?>(null)
  val viewStateMap = mutableStateMapOf<String, ItemsPage?>()

  init {
    viewModelScope.launch {
      filter.collect { filter ->
        if (filter == null) {
          if (summaryPage == null) {
            val hideExplicit = context.dataStore.get(HideExplicitKey, false)
            val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)
            val hideYoutubeShorts = context.dataStore.get(HideYoutubeShortsKey, false)
            
            // Fetch Addons first
            var addonItems: List<com.music.innertube.models.SongItem> = emptyList()
            try {
                addonItems = extensionManager.search(query)
            } catch (e: Exception) {}

            YouTube.searchSummary(query)
              .onSuccess {
                val filtered = it.filterExplicit(hideExplicit)
                    .filterVideoSongs(hideVideoSongs)
                    .filterYoutubeShorts(hideYoutubeShorts)
                    
                // Append addons if they exist
                if (addonItems.isNotEmpty()) {
                    val modSummaries = filtered.summaries.toMutableList()
                    modSummaries.add(0, com.music.innertube.pages.SearchSummary(title = "Addons", items = addonItems))
                    summaryPage = com.music.innertube.pages.SearchSummaryPage(summaries = modSummaries)
                } else {
                    summaryPage = filtered
                }
              }
              .onFailure { reportException(it) }
          }
        } else {
          if (viewStateMap[filter.value] == null) {
            YouTube.search(query, filter)
              .onSuccess { result ->
                val hideExplicit = context.dataStore.get(HideExplicitKey, false)
                val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)
                val hideYoutubeShorts = context.dataStore.get(HideYoutubeShortsKey, false)
                viewStateMap[filter.value] =
                  ItemsPage(
                    result.items
                      .distinctBy { it.id }
                      .filterExplicit(
                        hideExplicit,
                      )
                      .let { items ->
                        if (filter.value == YouTube.SearchFilter.FILTER_VIDEO.value) items
                        else items.filterVideoSongs(hideVideoSongs)
                      }
                      .filterYoutubeShorts(hideYoutubeShorts),
                    result.continuation,
                  )
              }
              .onFailure { reportException(it) }
          }
        }
      }
    }
  }

  fun loadMore() {
    val filter = filter.value?.value
    viewModelScope.launch {
      if (filter == null) return@launch
      val viewState = viewStateMap[filter] ?: return@launch
      val continuation = viewState.continuation
      if (continuation != null) {
        val searchResult = YouTube.searchContinuation(continuation).getOrNull() ?: return@launch
        val hideExplicit = context.dataStore.get(HideExplicitKey, false)
        val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)
        val hideYoutubeShorts = context.dataStore.get(HideYoutubeShortsKey, false)
        val newItems =
          searchResult.items
            .filterExplicit(hideExplicit)
            .let { items ->
              if (filter == YouTube.SearchFilter.FILTER_VIDEO.value) items
              else items.filterVideoSongs(hideVideoSongs)
            }
            .filterYoutubeShorts(hideYoutubeShorts)
        viewStateMap[filter] =
          ItemsPage((viewState.items + newItems).distinctBy { it.id }, searchResult.continuation)
      }
    }
  }
}
