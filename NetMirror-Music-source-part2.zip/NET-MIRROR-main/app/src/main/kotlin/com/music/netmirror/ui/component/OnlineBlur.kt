package netmirror.music.iad1tya.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import netmirror.music.iad1tya.ui.utils.fadingEdge

@Composable
fun OnlineBlur(
  thumbnailUrl: String?,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier) {
    if (thumbnailUrl != null) {
      AsyncImage(
        model = thumbnailUrl,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize().blur(50.dp).fadingEdge(bottom = 200.dp)
      )
    }

    Box(
      modifier =
        Modifier.fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors =
                listOf(Color.Transparent, MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
            )
          )
    )
  }
}
