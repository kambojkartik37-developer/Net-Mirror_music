package netmirror.music.iad1tya.ui.screens.settings

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import netmirror.music.iad1tya.BuildConfig
import netmirror.music.iad1tya.R

data class SearchableSetting(
  val title: String,
  val description: String?,
  val category: String,
  val route: String
)

@Composable
fun getAllSearchableSettings(): List<SearchableSetting> {
  return listOf(
    SearchableSetting(
      stringResource(R.string.about),
      stringResource(R.string.about_desc),
      "About",
      "settings/about"
    ),
    SearchableSetting(
      stringResource(R.string.account),
      stringResource(R.string.account_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.action_exported),
      stringResource(R.string.action_exported_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.action_logout),
      stringResource(R.string.action_logout_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.advanced_login),
      stringResource(R.string.advanced_login_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.ai_api_key),
      stringResource(R.string.ai_api_key_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_base_url),
      stringResource(R.string.ai_base_url_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_deepl_formality),
      stringResource(R.string.ai_deepl_formality_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_deepl_formality_default),
      stringResource(R.string.ai_deepl_formality_default_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_deepl_formality_less),
      stringResource(R.string.ai_deepl_formality_less_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_deepl_formality_more),
      stringResource(R.string.ai_deepl_formality_more_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_lyrics_translation),
      stringResource(R.string.ai_lyrics_translation_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_model),
      stringResource(R.string.ai_model_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider),
      stringResource(R.string.ai_provider_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_claude_help),
      stringResource(R.string.ai_provider_claude_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_deepl_help),
      stringResource(R.string.ai_provider_deepl_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_gemini_help),
      stringResource(R.string.ai_provider_gemini_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_help),
      stringResource(R.string.ai_provider_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_mistral_help),
      stringResource(R.string.ai_provider_mistral_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_nvidia_help),
      stringResource(R.string.ai_provider_nvidia_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_openai_help),
      stringResource(R.string.ai_provider_openai_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_openrouter_help),
      stringResource(R.string.ai_provider_openrouter_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_opper_help),
      stringResource(R.string.ai_provider_opper_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_perplexity_help),
      stringResource(R.string.ai_provider_perplexity_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_requesty_help),
      stringResource(R.string.ai_provider_requesty_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_api_route_help),
      stringResource(R.string.ai_provider_api_route_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_provider_xai_help),
      stringResource(R.string.ai_provider_xai_help_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_setup_guide),
      stringResource(R.string.ai_setup_guide_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_target_language),
      stringResource(R.string.ai_target_language_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_translation_literal),
      stringResource(R.string.ai_translation_literal_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_translation_mode),
      stringResource(R.string.ai_translation_mode_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_translation_transcribed),
      stringResource(R.string.ai_translation_transcribed_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.album_text),
      stringResource(R.string.album_text_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.albums),
      stringResource(R.string.albums_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.app_language),
      stringResource(R.string.app_language_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.app_update_uptodate),
      stringResource(R.string.app_update_uptodate_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.app_updates_title),
      stringResource(R.string.app_updates_title_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.appearance),
      stringResource(R.string.appearance_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.apple_music),
      stringResource(R.string.apple_music_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.apple_music_lyrics_blur),
      stringResource(R.string.apple_music_lyrics_blur_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.apple_music_style),
      stringResource(R.string.apple_music_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.apple_music_style_letter),
      stringResource(R.string.apple_music_style_letter_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.artist_page_settings),
      stringResource(R.string.artist_page_settings_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.artists),
      stringResource(R.string.artists_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.audio_normalization),
      stringResource(R.string.audio_normalization_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.varispeed),
      stringResource(R.string.varispeed_description),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.audio_offload),
      stringResource(R.string.audio_offload_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.audio_offload_disabled_by_crossfade),
      stringResource(R.string.audio_offload_disabled_by_crossfade_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.audio_quality),
      stringResource(R.string.audio_quality_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.auto_download_on_like),
      stringResource(R.string.auto_download_on_like_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.auto_load_more),
      stringResource(R.string.auto_load_more_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.auto_playlists),
      stringResource(R.string.auto_playlists_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.auto_skip_next_on_error),
      stringResource(R.string.auto_skip_next_on_error_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.auto_update_check),
      stringResource(R.string.auto_update_check_subtitle),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.backup_restore),
      stringResource(R.string.backup_restore_desc),
      "Backup & Restore",
      "settings/backup_restore"
    ),
    SearchableSetting(
      stringResource(R.string.big),
      stringResource(R.string.big_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.cache_size_warning_confirm),
      stringResource(R.string.cache_size_warning_confirm_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.cache_size_warning_message),
      stringResource(R.string.cache_size_warning_message_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.cache_size_warning_title),
      stringResource(R.string.cache_size_warning_title_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.cd_back),
      stringResource(R.string.cd_back_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.cd_palette_item),
      stringResource(R.string.cd_palette_item_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.center),
      stringResource(R.string.center_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.clear_all_downloads),
      stringResource(R.string.clear_all_downloads_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.clear_downloaded_updates),
      stringResource(R.string.clear_downloaded_updates_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.clear_downloads_dialog),
      stringResource(R.string.clear_downloads_dialog_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.clear_image_cache),
      stringResource(R.string.clear_image_cache_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.clear_image_cache_dialog),
      stringResource(R.string.clear_image_cache_dialog_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.clear_listen_history),
      stringResource(R.string.clear_listen_history_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.clear_listen_history_confirm),
      stringResource(R.string.clear_listen_history_confirm_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.clear_search_history),
      stringResource(R.string.clear_search_history_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.clear_search_history_confirm),
      stringResource(R.string.clear_search_history_confirm_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.clear_song_cache),
      stringResource(R.string.clear_song_cache_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.clear_song_cache_dialog),
      stringResource(R.string.clear_song_cache_dialog_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.close),
      stringResource(R.string.close_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.color_palette),
      stringResource(R.string.color_palette_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.commits),
      stringResource(R.string.commits_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.config_proxy),
      stringResource(R.string.config_proxy_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.content),
      stringResource(R.string.content_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.content_country),
      stringResource(R.string.content_country_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.content_language),
      stringResource(R.string.content_language_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.crop_album_art),
      stringResource(R.string.crop_album_art_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.crossfade),
      stringResource(R.string.crossfade_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.crossfade_beta_message),
      stringResource(R.string.crossfade_beta_message_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.crossfade_beta_title),
      stringResource(R.string.crossfade_beta_title_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.crossfade_duration),
      stringResource(R.string.crossfade_duration_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.crossfade_gapless),
      stringResource(R.string.crossfade_gapless_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.dark_theme_follow_system),
      stringResource(R.string.dark_theme_follow_system_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.default_),
      stringResource(R.string.default__desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.default_lib_chips),
      stringResource(R.string.default_lib_chips_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.default_open_tab),
      stringResource(R.string.default_open_tab_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.default_style),
      stringResource(R.string.default_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.density_restart_message),
      stringResource(R.string.density_restart_message_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.disable),
      stringResource(R.string.disable_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.disable_load_more_when_repeat_all),
      stringResource(R.string.disable_load_more_when_repeat_all_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.disable_screenshot),
      stringResource(R.string.disable_screenshot_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.display_density),
      stringResource(R.string.display_density_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.download_quality_title),
      stringResource(R.string.download_quality_title_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.downloaded_songs),
      stringResource(R.string.downloaded_songs_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.echo_equalizer),
      stringResource(R.string.echo_equalizer_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.netmirror_1),
      stringResource(R.string.netmirror_1_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.netmirror_canvas),
      stringResource(R.string.netmirror_canvas_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.enable),
      stringResource(R.string.enable_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.enable_authentication),
      stringResource(R.string.enable_authentication_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.enable_better_lyrics),
      stringResource(R.string.enable_better_lyrics_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.enable_dynamic_theme),
      stringResource(R.string.enable_dynamic_theme_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.enable_high_refresh_rate),
      stringResource(R.string.enable_high_refresh_rate_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.enable_kugou),
      stringResource(R.string.enable_kugou_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.enable_lrclib),
      stringResource(R.string.enable_lrclib_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.enable_proxy),
      stringResource(R.string.enable_proxy_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.enable_similar_content),
      stringResource(R.string.enable_similar_content_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.enable_simpmusic),
      stringResource(R.string.enable_simpmusic_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.enable_swipe_thumbnail),
      stringResource(R.string.enable_swipe_thumbnail_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.export_directory),
      stringResource(R.string.export_directory_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.fade),
      stringResource(R.string.fade_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.filter_library),
      stringResource(R.string.filter_library_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.filter_local),
      stringResource(R.string.filter_local_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.follow_theme),
      stringResource(R.string.follow_theme_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.general),
      stringResource(R.string.general_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.glow),
      stringResource(R.string.glow_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.glow_animated),
      stringResource(R.string.glow_animated_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.google_cast),
      stringResource(R.string.google_cast_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.gradient),
      stringResource(R.string.gradient_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.grid_cell_size),
      stringResource(R.string.grid_cell_size_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.hide_explicit),
      stringResource(R.string.hide_explicit_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.hide_player_thumbnail),
      stringResource(R.string.hide_player_thumbnail_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.hide_status_bar_on_fullscreen),
      stringResource(R.string.hide_status_bar_on_fullscreen_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.hide_video_songs),
      stringResource(R.string.hide_video_songs_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.hide_youtube_shorts),
      stringResource(R.string.hide_youtube_shorts_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.history_duration),
      stringResource(R.string.history_duration_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.home),
      stringResource(R.string.home_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.image_cache),
      stringResource(R.string.image_cache_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.ip_version_auto),
      stringResource(R.string.ip_version_auto_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.ip_version_ipv4),
      stringResource(R.string.ip_version_ipv4_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.ip_version_ipv6),
      stringResource(R.string.ip_version_ipv6_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.karaoke),
      stringResource(R.string.karaoke_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.keep_screen_on_when_player_is_expanded),
      stringResource(R.string.keep_screen_on_when_player_is_expanded_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.last_song_listened),
      stringResource(R.string.last_song_listened_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.left),
      stringResource(R.string.left_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.legacy_icon),
      stringResource(R.string.legacy_icon_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.line_by_line_dialog_title),
      stringResource(R.string.line_by_line_dialog_title_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.line_by_line_option_title),
      stringResource(R.string.line_by_line_option_title_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.listen_history),
      stringResource(R.string.listen_history_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_in_top_bar),
      stringResource(R.string.listen_together_in_top_bar_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.live_mesh),
      stringResource(R.string.live_mesh_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.login),
      stringResource(R.string.login_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.logout_clear_data),
      stringResource(R.string.logout_clear_data_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.logout_dialog_message),
      stringResource(R.string.logout_dialog_message_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.logout_dialog_title),
      stringResource(R.string.logout_dialog_title_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.logout_keep_data),
      stringResource(R.string.logout_keep_data_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.logs_heading),
      stringResource(R.string.logs_heading_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics),
      stringResource(R.string.lyrics_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_animation_metro),
      stringResource(R.string.lyrics_animation_metro_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_animation_style),
      stringResource(R.string.lyrics_animation_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_auto_scroll),
      stringResource(R.string.lyrics_auto_scroll_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_click_change),
      stringResource(R.string.lyrics_click_change_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_glow_effect),
      stringResource(R.string.lyrics_glow_effect_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_line_spacing),
      stringResource(R.string.lyrics_line_spacing_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_provider_priority),
      stringResource(R.string.lyrics_provider_priority_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanization),
      stringResource(R.string.lyrics_romanization_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_as_main),
      stringResource(R.string.lyrics_romanize_as_main_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_belarusian),
      stringResource(R.string.lyrics_romanize_belarusian_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_bulgarian),
      stringResource(R.string.lyrics_romanize_bulgarian_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_chinese),
      stringResource(R.string.lyrics_romanize_chinese_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_hindi),
      stringResource(R.string.lyrics_romanize_hindi_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_japanese),
      stringResource(R.string.lyrics_romanize_japanese_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_korean),
      stringResource(R.string.lyrics_romanize_korean_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_kyrgyz),
      stringResource(R.string.lyrics_romanize_kyrgyz_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_macedonian),
      stringResource(R.string.lyrics_romanize_macedonian_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_punjabi),
      stringResource(R.string.lyrics_romanize_punjabi_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_russian),
      stringResource(R.string.lyrics_romanize_russian_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_serbian),
      stringResource(R.string.lyrics_romanize_serbian_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_title),
      stringResource(R.string.lyrics_romanize_title_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_romanize_ukrainian),
      stringResource(R.string.lyrics_romanize_ukrainian_desc),
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_swipe_to_change_song),
      stringResource(R.string.lyrics_swipe_to_change_song_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_text_position),
      stringResource(R.string.lyrics_text_position_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_text_size),
      stringResource(R.string.lyrics_text_size_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_thumbnail_play_pause),
      stringResource(R.string.lyrics_thumbnail_play_pause_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.lyrics_v2_fluid),
      stringResource(R.string.lyrics_v2_fluid_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.max_image_cache_size),
      stringResource(R.string.max_image_cache_size_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.max_song_cache_size),
      stringResource(R.string.max_song_cache_size_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.mini_player),
      stringResource(R.string.mini_player_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.miniplayer_background_style),
      stringResource(R.string.miniplayer_background_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.misc),
      stringResource(R.string.misc_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.more_content),
      stringResource(R.string.more_content_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.network_ip_version),
      stringResource(R.string.network_ip_version_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.none),
      stringResource(R.string.none_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.not_set),
      stringResource(R.string.not_set_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.palette_amber),
      stringResource(R.string.palette_amber_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_blue),
      stringResource(R.string.palette_blue_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_blue_grey),
      stringResource(R.string.palette_blue_grey_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_brown),
      stringResource(R.string.palette_brown_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_crimson),
      stringResource(R.string.palette_crimson_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_cyan),
      stringResource(R.string.palette_cyan_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_deep_orange),
      stringResource(R.string.palette_deep_orange_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_deep_purple),
      stringResource(R.string.palette_deep_purple_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_dynamic),
      stringResource(R.string.palette_dynamic_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_green),
      stringResource(R.string.palette_green_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_grey),
      stringResource(R.string.palette_grey_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_indigo),
      stringResource(R.string.palette_indigo_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_light_green),
      stringResource(R.string.palette_light_green_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_lime),
      stringResource(R.string.palette_lime_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_orange),
      stringResource(R.string.palette_orange_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_purple),
      stringResource(R.string.palette_purple_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_rose),
      stringResource(R.string.palette_rose_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_sky_blue),
      stringResource(R.string.palette_sky_blue_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_teal),
      stringResource(R.string.palette_teal_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.palette_yellow),
      stringResource(R.string.palette_yellow_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.pause_listen_history),
      stringResource(R.string.pause_listen_history_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.pause_music_when_media_is_muted),
      stringResource(R.string.pause_music_when_media_is_muted_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.pause_search_history),
      stringResource(R.string.pause_search_history_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.persistent_queue),
      stringResource(R.string.persistent_queue_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.persistent_shuffle_title),
      stringResource(R.string.persistent_shuffle_title_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.playback_logs),
      stringResource(R.string.playback_logs_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.player),
      stringResource(R.string.player_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.player_and_audio),
      stringResource(R.string.player_and_audio_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting("Playback Engine", null, "Player and audio", "settings/player"),
    SearchableSetting(
      stringResource(R.string.player_background_blur),
      stringResource(R.string.player_background_blur_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.player_background_style),
      stringResource(R.string.player_background_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.player_buttons_style),
      stringResource(R.string.player_buttons_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.player_slider_style),
      stringResource(R.string.player_slider_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.playlists),
      stringResource(R.string.playlists_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.prevent_duplicate_tracks_in_queue),
      stringResource(R.string.prevent_duplicate_tracks_in_queue_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.primary_color_style),
      stringResource(R.string.primary_color_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.privacy),
      stringResource(R.string.privacy_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.proxy),
      stringResource(R.string.proxy_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.proxy_password),
      stringResource(R.string.proxy_password_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.proxy_type),
      stringResource(R.string.proxy_type_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.proxy_url),
      stringResource(R.string.proxy_url_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.proxy_username),
      stringResource(R.string.proxy_username_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.queue),
      stringResource(R.string.queue_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.quick_picks),
      stringResource(R.string.quick_picks_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.randomize_home_order),
      stringResource(R.string.randomize_home_order_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.remember_shuffle_and_repeat),
      stringResource(R.string.remember_shuffle_and_repeat_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.reset),
      stringResource(R.string.reset_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.restart),
      stringResource(R.string.restart_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.restart_required),
      stringResource(R.string.restart_required_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.resume_on_bluetooth_connect),
      stringResource(R.string.resume_on_bluetooth_connect_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.right),
      stringResource(R.string.right_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.rotating_thumbnail),
      stringResource(R.string.rotating_thumbnail_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.save),
      stringResource(R.string.save_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.search_history),
      stringResource(R.string.search_history_desc),
      "Privacy",
      "settings/privacy"
    ),
    SearchableSetting(
      stringResource(R.string.seek_seconds_addup),
      stringResource(R.string.seek_seconds_addup_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.sensitivity_percentage),
      stringResource(R.string.sensitivity_percentage_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.set_quick_picks),
      stringResource(R.string.set_quick_picks_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.settings_section_player_content),
      stringResource(R.string.settings_section_player_content_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.show_album_canvas),
      stringResource(R.string.show_album_canvas_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.show_artist_background_video),
      stringResource(R.string.show_artist_background_video_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.show_artist_monthly_listeners),
      stringResource(R.string.show_artist_monthly_listeners_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.show_artist_subscriber_count),
      stringResource(R.string.show_artist_subscriber_count_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.show_artist_video),
      stringResource(R.string.show_artist_video_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.show_bottom_playlist),
      stringResource(R.string.show_bottom_playlist_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.show_cached_playlist),
      stringResource(R.string.show_cached_playlist_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.show_comment_button),
      stringResource(R.string.show_comment_button_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.show_downloaded_playlist),
      stringResource(R.string.show_downloaded_playlist_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.show_liked_playlist),
      stringResource(R.string.show_liked_playlist_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.show_top_playlist),
      stringResource(R.string.show_top_playlist_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.show_uploaded_playlist),
      stringResource(R.string.show_uploaded_playlist_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.shuffle_playlist_first),
      stringResource(R.string.shuffle_playlist_first_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.skip_silence),
      stringResource(R.string.skip_silence_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.skip_silence_instant),
      stringResource(R.string.skip_silence_instant_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.slide),
      stringResource(R.string.slide_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.slim),
      stringResource(R.string.slim_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.small),
      stringResource(R.string.small_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.song_cache),
      stringResource(R.string.song_cache_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.songs),
      stringResource(R.string.songs_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.squiggly),
      stringResource(R.string.squiggly_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.standard_lyrics_blur),
      stringResource(R.string.standard_lyrics_blur_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.stop_music_on_task_clear),
      stringResource(R.string.stop_music_on_task_clear_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.storage),
      stringResource(R.string.storage_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.swipe_sensitivity),
      stringResource(R.string.swipe_sensitivity_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.swipe_song_to_add),
      stringResource(R.string.swipe_song_to_add_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.swipe_song_to_remove),
      stringResource(R.string.swipe_song_to_remove_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.system_default),
      stringResource(R.string.system_default_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.system_update),
      stringResource(R.string.system_update_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.tertiary_color_style),
      stringResource(R.string.tertiary_color_style_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.theme),
      stringResource(R.string.theme_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.theme_colors),
      stringResource(R.string.theme_colors_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.theme_mode),
      stringResource(R.string.theme_mode_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.thumbnail_corner_radius),
      stringResource(R.string.thumbnail_corner_radius_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.token_hidden),
      stringResource(R.string.token_hidden_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.token_shown),
      stringResource(R.string.token_shown_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.top_length),
      stringResource(R.string.top_length_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.unlimited),
      stringResource(R.string.unlimited_desc),
      "Storage",
      "settings/storage"
    ),
    SearchableSetting(
      stringResource(R.string.update_available),
      stringResource(R.string.update_available_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.update_notifications),
      stringResource(R.string.update_notifications_subtitle),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.update_settings_title),
      stringResource(R.string.update_settings_title_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.version),
      stringResource(R.string.version_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.view_commit_history),
      stringResource(R.string.view_commit_history_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.wavy),
      stringResource(R.string.wavy_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.wavy_play_pause),
      stringResource(R.string.wavy_play_pause_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.yt_sync),
      stringResource(R.string.yt_sync_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting("Import from Spotify", null, "Backup & Restore", "settings/spotify_import"),
    SearchableSetting(
      "Import from local file",
      null,
      "Backup & Restore",
      "settings/backup_restore"
    ),
    SearchableSetting("Import 'm3u' Playlist", null, "Backup & Restore", "settings/backup_restore"),
    SearchableSetting("Import 'csv' Playlist", null, "Backup & Restore", "settings/backup_restore"),
    SearchableSetting("Local Backup", null, "Backup & Restore", "settings/backup_restore"),
    SearchableSetting("Equalizer", null, "Player and audio", "settings/equalizer"),
    SearchableSetting("Integrations", null, "Settings", "settings/integrations"),
    SearchableSetting(
      "Listen Together",
      null,
      "Integrations",
      "settings/integrations/listen_together"
    ),
    SearchableSetting("YouLyPlus", null, "Content", "settings/content"),
    SearchableSetting("PaxSenix", null, "Content", "settings/content"),
    SearchableSetting("Apple Music Inspired", null, "Appearance", "settings/appearance"),
    SearchableSetting(
      stringResource(R.string.version, BuildConfig.VERSION_NAME),
      stringResource(R.string.version_desc),
      "System Update",
      "settings/update"
    ),
    SearchableSetting(
      stringResource(R.string.discord_integration),
      stringResource(R.string.discord_integration_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.lastfm_integration),
      stringResource(R.string.lastfm_integration_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.listenbrainz_scrobbling),
      stringResource(R.string.listenbrainz_scrobbling_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      stringResource(R.string.set_listenbrainz_token),
      stringResource(R.string.set_listenbrainz_token_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting("Preload Next Song", null, "Player and audio", "settings/player"),
    SearchableSetting("Preload Limit", null, "Player and audio", "settings/player"),
    SearchableSetting("Preload Lyrics", null, "Player and audio", "settings/player"),
    SearchableSetting("Suggestions Region", null, "Content", "settings/content"),
    SearchableSetting(
      stringResource(R.string.content_sponsor_block),
      stringResource(R.string.content_sponsor_block_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting("Speed Dial", null, "Content", "settings/content"),
    SearchableSetting(
      stringResource(R.string.service_uptime),
      stringResource(R.string.service_uptime_desc),
      "Content",
      "settings/content"
    ),
    SearchableSetting("Hide volume slider", null, "Appearance", "settings/appearance"),
    SearchableSetting("Show codec on player", null, "Appearance", "settings/appearance"),
    SearchableSetting(
      stringResource(R.string.experiment_settings),
      stringResource(R.string.experiment_settings_desc),
      "Discord",
      "settings/discord/experimental"
    ),
    SearchableSetting("Show Button 1", null, "Discord", "settings/discord/experimental"),
    SearchableSetting("Button 1 Label", null, "Discord", "settings/discord/experimental"),
    SearchableSetting("Button 1 URL Source", null, "Discord", "settings/discord/experimental"),
    SearchableSetting("Button 1 Custom URL", null, "Discord", "settings/discord/experimental"),
    SearchableSetting("Show Button 2", null, "Discord", "settings/discord/experimental"),
    SearchableSetting("Button 2 Label", null, "Discord", "settings/discord/experimental"),
    SearchableSetting("Button 2 URL Source", null, "Discord", "settings/discord/experimental"),
    SearchableSetting("Button 2 Custom URL", null, "Discord", "settings/discord/experimental"),
    SearchableSetting(
      stringResource(R.string.enable_scrobbling),
      stringResource(R.string.enable_scrobbling_desc),
      "Last.fm",
      "settings/lastfm"
    ),
    SearchableSetting(
      stringResource(R.string.lastfm_now_playing),
      stringResource(R.string.lastfm_now_playing_desc),
      "Last.fm",
      "settings/lastfm"
    ),
    SearchableSetting(
      stringResource(R.string.last_fm_send_likes),
      stringResource(R.string.last_fm_send_likes_desc),
      "Last.fm",
      "settings/lastfm"
    ),
    SearchableSetting(
      stringResource(R.string.scrobble_min_track_duration),
      stringResource(R.string.scrobble_min_track_duration_desc),
      "Last.fm",
      "settings/lastfm"
    ),
    SearchableSetting(
      stringResource(R.string.scrobble_delay_percent),
      stringResource(R.string.scrobble_delay_percent_desc),
      "Last.fm",
      "settings/lastfm"
    ),
    SearchableSetting(
      stringResource(R.string.scrobble_delay_minutes),
      stringResource(R.string.scrobble_delay_minutes_desc),
      "Last.fm",
      "settings/lastfm"
    ),
    SearchableSetting("Import", null, "Backup & Restore", "settings/backup_restore"),
    SearchableSetting(
      "DeepL ${stringResource(R.string.ai_api_key)}",
      stringResource(R.string.ai_api_key_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_auto_translate),
      stringResource(R.string.ai_auto_translate_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_recommendations),
      stringResource(R.string.ai_recommendations_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting(
      stringResource(R.string.ai_recommendations_refresh),
      stringResource(R.string.ai_recommendations_refresh_desc),
      "AI Lyrics Translation",
      "settings/ai"
    ),
    SearchableSetting("Supported Links", null, "Settings", "settings"),
    SearchableSetting(
      stringResource(R.string.refresh),
      stringResource(R.string.refresh_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.activity_status),
      stringResource(R.string.activity_status_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.platform_status),
      stringResource(R.string.platform_status_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.discord_activity_name),
      stringResource(R.string.discord_activity_name_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.discord_activity_details),
      stringResource(R.string.discord_activity_details_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.discord_activity_state),
      stringResource(R.string.discord_activity_state_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.discord_show_when_paused),
      stringResource(R.string.discord_show_when_paused_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.discord_activity_type),
      stringResource(R.string.discord_activity_type_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.large_image),
      stringResource(R.string.large_image_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.large_image_custom_url),
      stringResource(R.string.large_image_custom_url_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.small_image),
      stringResource(R.string.small_image_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.small_image_custom_url),
      stringResource(R.string.small_image_custom_url_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting(
      stringResource(R.string.logout_confirm_title),
      stringResource(R.string.logout_confirm_title_desc),
      "Discord",
      "settings/discord"
    ),
    SearchableSetting("Edit", null, "Discord", "settings/discord"),
    SearchableSetting(
      stringResource(R.string.automix),
      stringResource(R.string.automix_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.automix_debug),
      stringResource(R.string.automix_debug_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.enable_haptics),
      stringResource(R.string.enable_haptics_desc),
      "Appearance",
      "settings/appearance/haptics"
    ),
    SearchableSetting(
      stringResource(R.string.haptics_intensity),
      stringResource(R.string.haptics_intensity_desc),
      "Appearance",
      "settings/appearance/haptics"
    ),
    SearchableSetting(
      stringResource(R.string.haptic_click_feedback),
      stringResource(R.string.haptic_click_feedback_desc),
      "Appearance",
      "settings/appearance/haptics"
    ),
    SearchableSetting(
      stringResource(R.string.haptic_long_press_feedback),
      stringResource(R.string.haptic_long_press_feedback_desc),
      "Appearance",
      "settings/appearance/haptics"
    ),
    SearchableSetting(
      stringResource(R.string.haptic_scroll_edge_feedback),
      stringResource(R.string.haptic_scroll_edge_feedback_desc),
      "Appearance",
      "settings/appearance/haptics"
    ),
    SearchableSetting(
      stringResource(R.string.haptic_slider_feedback),
      stringResource(R.string.haptic_slider_feedback_desc),
      "Appearance",
      "settings/appearance/haptics"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_username),
      stringResource(R.string.listen_together_username_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_create_room),
      stringResource(R.string.listen_together_create_room_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_join_room),
      stringResource(R.string.listen_together_join_room_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_blocked_users),
      stringResource(R.string.listen_together_blocked_users_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_server_url),
      stringResource(R.string.listen_together_server_url_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_auto_approval),
      stringResource(R.string.listen_together_auto_approval_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_sync_volume),
      stringResource(R.string.listen_together_sync_volume_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_smart_resync),
      stringResource(R.string.listen_together_smart_resync_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_view_logs),
      stringResource(R.string.listen_together_view_logs_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together),
      stringResource(R.string.listen_together_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_logs),
      stringResource(R.string.listen_together_logs_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting(
      stringResource(R.string.listen_together_choose_server),
      stringResource(R.string.listen_together_choose_server_desc),
      "Listen Together",
      "settings/integrations/listen_together"
    ),
    SearchableSetting("Data Saver Mode (Beta)", null, "Player and audio", "settings/player"),
    SearchableSetting(
      stringResource(R.string.audio_offload_description),
      null,
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.export_desc),
      null,
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.google_cast_description),
      null,
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.line_by_line_dialog_desc),
      null,
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.line_by_line_option_desc),
      null,
      "Romanization",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.persistent_shuffle_desc),
      null,
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.seek_seconds_addup_description),
      null,
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.show_artist_description),
      null,
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.show_comment_button_description),
      null,
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      stringResource(R.string.similar_content_desc),
      null,
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.token_adv_login_description),
      null,
      "Account",
      "settings/account"
    ),

    // Hardcoded Settings Missed by Generator
    SearchableSetting(
      "Liquid Glass",
      "Real-time backdrop blur effect for the player",
      "Appearance",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.floating_nav_bar),
      stringResource(R.string.floating_nav_bar_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_global_enabled),
      stringResource(R.string.liquid_glass_global_enabled_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_vibrancy),
      stringResource(R.string.liquid_glass_vibrancy_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_blur_radius),
      stringResource(R.string.liquid_glass_blur_radius_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_lens_height),
      stringResource(R.string.liquid_glass_lens_height_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_lens_amount),
      stringResource(R.string.liquid_glass_lens_amount_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_chromatic_aberration),
      stringResource(R.string.liquid_glass_chromatic_aberration_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_depth_effect),
      stringResource(R.string.liquid_glass_depth_effect_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_surface_opacity),
      stringResource(R.string.liquid_glass_surface_opacity_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_surface_tint),
      stringResource(R.string.liquid_glass_surface_tint_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_text_color),
      stringResource(R.string.liquid_glass_text_color_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_player),
      stringResource(R.string.liquid_glass_player_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_mini_player),
      stringResource(R.string.liquid_glass_mini_player_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_nav_bar),
      stringResource(R.string.liquid_glass_nav_bar_desc),
      "Liquid Glass",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      "Ambient Mode",
      "Customize the appearance of the ambient player",
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      "Music Art Size",
      "Change the album art size in Ambient Mode",
      "Ambient Mode",
      "ambient_settings"
    ),
    SearchableSetting(
      "Show Song Name",
      "Display the current song title in Ambient Mode",
      "Ambient Mode",
      "ambient_settings"
    ),
    SearchableSetting(
      "Show Artist Name",
      "Display the current artist name in Ambient Mode",
      "Ambient Mode",
      "ambient_settings"
    ),
    SearchableSetting(
      "Show Lyrics",
      "Display synchronized lyrics if available in Ambient Mode",
      "Ambient Mode",
      "ambient_settings"
    ),
    SearchableSetting(
      stringResource(R.string.show_seek_buttons),
      stringResource(R.string.show_seek_buttons_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.download_on_wifi_only),
      stringResource(R.string.download_on_wifi_only_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.audio_loudness_preset),
      null,
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      stringResource(R.string.spatial_audio),
      stringResource(R.string.spatial_audio_desc),
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Fetch faster lyrics",
      "Search for lyrics in parallel and choose the provider that responds first, ignoring priority",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.discord),
      stringResource(R.string.discord_integration_desc),
      "Account",
      "settings/account"
    ),
    SearchableSetting("Add another account", null, "Account", "settings/account"),
    SearchableSetting("Edit Discord Profile", null, "Discord", "settings/discord"),
    SearchableSetting(stringResource(R.string.preview), null, "Discord", "settings/discord"),
    SearchableSetting(stringResource(R.string.not_logged_in), null, "LastFM", "settings/lastfm"),

    // App Icon Settings
    SearchableSetting(
      "App Icon",
      "Choose your launcher icon",
      "Appearance",
      "settings/appearance/app_icon"
    ),

    // About Screen - Social & Support Links
    SearchableSetting("Website", "Visit the NET-MIRROR website", "About", "settings/about"),
    SearchableSetting("Instagram", "Follow NET-MIRROR on Instagram", "About", "settings/about"),
    SearchableSetting("X (Twitter)", "Follow NET-MIRROR on X", "About", "settings/about"),
    SearchableSetting("Buy Me a Coffee", "Support the developer", "About", "settings/about"),
    SearchableSetting("Patreon", "Support the developer on Patreon", "About", "settings/about"),
    SearchableSetting("UPI", "Support the developer via UPI", "About", "settings/about"),
    SearchableSetting("Discord", "Join the NET-MIRROR community", "About", "settings/about"),
  ) + listOf(
    SearchableSetting(
      "Show Button 1",
      "Show Button 1 in Discord Rich Presence",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Button 1 Label",
      "Label for Button 1",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Button 1 URL Source",
      "URL Source for Button 1",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Button 1 Custom URL",
      "Custom URL for Button 1",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Show Button 2",
      "Show Button 2 in Discord Rich Presence",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Button 2 Label",
      "Label for Button 2",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Button 2 URL Source",
      "URL Source for Button 2",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Button 2 Custom URL",
      "Custom URL for Button 2",
      "Discord RPC",
      "settings/discord/experimental"
    ),
    SearchableSetting(
      "Local Backup",
      "Create a local backup",
      "Backup and Restore",
      "settings/backup_restore"
    ),
    SearchableSetting(
      "Import",
      "Import a local backup",
      "Backup and Restore",
      "settings/backup_restore"
    ),
    SearchableSetting(
      "Import from Spotify",
      "Import playlists from Spotify",
      "Backup and Restore",
      "settings/backup_restore"
    ),
    SearchableSetting(
      "Import 'm3u' Playlist",
      "Import an m3u playlist",
      "Backup and Restore",
      "settings/backup_restore"
    ),
    SearchableSetting(
      "Import 'csv' Playlist",
      "Import a csv playlist",
      "Backup and Restore",
      "settings/backup_restore"
    ),
    SearchableSetting(
      "Test Connection",
      "Test the connection to the AI provider",
      "AI Settings",
      "settings/ai"
    ),
    SearchableSetting(
      "Blocked Artists",
      "Manage blocked artists",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      "Add another account",
      "Add a new account",
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      "Spotify",
      "Connect to Spotify",
      "Account",
      "settings/account"
    ),
    SearchableSetting(
      "Supported Links",
      "Manage supported links",
      "Settings",
      "settings"
    ),
    SearchableSetting(
      stringResource(R.string.haptics),
      stringResource(R.string.haptics_desc),
      "Appearance",
      "settings/appearance/haptics"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass_settings),
      stringResource(R.string.liquid_glass_settings_desc),
      "Appearance",
      "settings/appearance/liquidglass"
    ),
    SearchableSetting(
      stringResource(R.string.app_font),
      "Choose the application font",
      "Appearance",
      "settings/appearance/font"
    ),
    SearchableSetting(
      "Data Saver Mode (Beta)",
      "Low quality streaming for data saving",
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Download with metadata",
      "Downloads lyrics when downloading a song",
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Playback Engine",
      "Choose the playback engine",
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Bit-Perfect USB-DAC Output",
      "Direct UAC1/UAC2 driver bypassing Android OS mixer",
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Preload Next Song",
      "Cache the next song for gapless playback",
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Preload Limit",
      "Limit for preloaded songs",
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Preload Lyrics",
      "Also cache lyrics for the preloaded songs",
      "Player and audio",
      "settings/player"
    ),
    SearchableSetting(
      "Show Music Art",
      "Show album art in ambient mode",
      "Appearance",
      "settings/ambient"
    ),
    SearchableSetting(
      "Spacing Between Art and Lyrics",
      "Adjust spacing between art and lyrics",
      "Appearance",
      "settings/ambient"
    ),
    SearchableSetting(
      "Lyrics Font Size",
      "Adjust lyrics font size",
      "Appearance",
      "settings/ambient"
    ),
    SearchableSetting(
      "Lyrics Line Spacing",
      "Adjust lyrics line spacing",
      "Appearance",
      "settings/ambient"
    ),
    SearchableSetting(
      "Lyrics Animation Style",
      "Choose lyrics animation style",
      "Appearance",
      "settings/ambient"
    ),
    SearchableSetting(
      "Ambient Mode Settings",
      "Configure ambient mode",
      "Appearance",
      "settings/ambient"
    ),
    SearchableSetting(
      "Add Custom Server",
      "Add a custom extension server",
      "Extensions",
      "settings/extensions"
    ),
    SearchableSetting(
      "Add Extension",
      "Add a new extension",
      "Extensions",
      "settings/extensions"
    ),
    SearchableSetting(
      "Extension Sources",
      "Manage extension sources",
      "Extensions",
      "settings/extensions"
    ),
    SearchableSetting(
      "Blocked Artists",
      "Manage blocked artists",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      "Force Opus Audio (itag 251)",
      "Force high quality Opus audio",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      "Enable HTTP/3 (Cronet)",
      "Enable experimental HTTP/3 support",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      "Suggestions Region",
      "Select region for suggestions",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.recommendation_source),
      "Select the source for content recommendations",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      "Speed Dial",
      "Configure speed dial",
      "Content",
      "settings/content"
    ),
    SearchableSetting(
      stringResource(R.string.liquid_glass),
      stringResource(R.string.liquid_glass_desc),
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      "Apple Music Inspired",
      "Apple Music inspired UI",
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      "Hide volume slider",
      "Hide volume slider in player",
      "Appearance",
      "settings/appearance"
    ),
    SearchableSetting(
      "Show codec on player",
      "Show audio codec information",
      "Appearance",
      "settings/appearance"
    ),
  ).filterNot { it.route == "settings/ambient" || it.route == "settings/integrations" }
    .distinctBy { it.title to it.route }
}
