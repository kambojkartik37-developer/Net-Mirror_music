package netmirror.music.iad1tya.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.music.innertube.YouTube
import com.music.innertube.models.AlbumItem
import com.music.innertube.models.ArtistItem
import com.music.innertube.models.PlaylistItem
import com.music.innertube.models.filterYoutubeShorts
import com.music.innertube.utils.completed
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import netmirror.music.iad1tya.constants.HideYoutubeShortsKey
import netmirror.music.iad1tya.ui.utils.resize
import netmirror.music.iad1tya.utils.dataStore
import netmirror.music.iad1tya.utils.get
import netmirror.music.iad1tya.utils.reportException
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

enum class AccountContentType {
  PLAYLISTS,
  ALBUMS,
  ARTISTS
}

@HiltViewModel
class AccountViewModel
@Inject
constructor(
  @ApplicationContext private val context: Context,
) : ViewModel() {
  val playlists = MutableStateFlow<List<PlaylistItem>?>(null)
  val albums = MutableStateFlow<List<AlbumItem>?>(null)
  val artists = MutableStateFlow<List<ArtistItem>?>(null)

  val selectedContentType = MutableStateFlow(AccountContentType.PLAYLISTS)

  private suspend fun loadPlaylists() {
    val hideYoutubeShorts = context.dataStore.get(HideYoutubeShortsKey, false)
    YouTube.library("FEmusic_liked_playlists")
      .completed()
      .onSuccess {
        playlists.value =
          it.items
            .filterIsInstance<PlaylistItem>()
            .filterNot { it.id == "SE" }
            .filterYoutubeShorts(hideYoutubeShorts)
      }
      .onFailure { reportException(it) }
  }

  init {
    viewModelScope.launch {
      loadPlaylists()
      YouTube.library("FEmusic_liked_albums")
        .completed()
        .onSuccess { albums.value = it.items.filterIsInstance<AlbumItem>() }
        .onFailure { reportException(it) }
      YouTube.library("FEmusic_library_corpus_artists")
        .completed()
        .onSuccess {
          artists.value =
            it.items.filterIsInstance<ArtistItem>().map { artist ->
              artist.copy(thumbnail = artist.thumbnail?.resize(1200, 1200))
            }
        }
        .onFailure { reportException(it) }
    }

    viewModelScope.launch(Dispatchers.IO) {
      context.dataStore.data
        .map {
          (try {
            it[HideYoutubeShortsKey]
          } catch (e: Exception) {
            null
          }) ?: false
        }
        .distinctUntilChanged()
        .collect {
          if (playlists.value != null) {
            loadPlaylists()
          }
        }
    }
  }

  fun setSelectedContentType(contentType: AccountContentType) {
    selectedContentType.value = contentType
  }
}
