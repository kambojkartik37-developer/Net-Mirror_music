package netmirror.music.iad1tya.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ContainedLoadingIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.fastForEachIndexed
import androidx.compose.ui.util.fastForEachReversed
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.media3.exoplayer.offline.Download
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import netmirror.music.iad1tya.LocalDatabase
import netmirror.music.iad1tya.LocalDownloadUtil
import netmirror.music.iad1tya.LocalPlayerAwareWindowInsets
import netmirror.music.iad1tya.LocalPlayerConnection
import netmirror.music.iad1tya.R
import netmirror.music.iad1tya.constants.AlbumCanvasEnabledKey
import netmirror.music.iad1tya.constants.AppBarHeight
import netmirror.music.iad1tya.constants.HideExplicitKey
import netmirror.music.iad1tya.constants.HideVideoSongsKey
import netmirror.music.iad1tya.db.entities.Album
import netmirror.music.iad1tya.playback.queues.LocalAlbumRadio
import netmirror.music.iad1tya.ui.component.ExpandableText
import netmirror.music.iad1tya.ui.component.HeartBurstIcon
import netmirror.music.iad1tya.ui.component.IconButton
import netmirror.music.iad1tya.ui.component.LinkSegment
import netmirror.music.iad1tya.ui.component.LocalMenuState
import netmirror.music.iad1tya.ui.component.NavigationTitle
import netmirror.music.iad1tya.ui.component.SongListItem
import netmirror.music.iad1tya.ui.component.YouTubeGridItem
import netmirror.music.iad1tya.ui.menu.AlbumMenu
import netmirror.music.iad1tya.ui.menu.SelectionSongMenu
import netmirror.music.iad1tya.ui.menu.SongMenu
import netmirror.music.iad1tya.ui.menu.YouTubeAlbumMenu
import netmirror.music.iad1tya.ui.player.CanvasArtworkPlayer
import netmirror.music.iad1tya.ui.utils.backToMain
import netmirror.music.iad1tya.utils.listItemShape
import netmirror.music.iad1tya.utils.rememberPreference
import netmirror.music.iad1tya.viewmodels.AlbumViewModel

@OptIn(
  ExperimentalFoundationApi::class,
  ExperimentalMaterial3Api::class,
  ExperimentalMaterial3ExpressiveApi::class
)
@Composable
fun AlbumScreen(
  navController: NavController,
  scrollBehavior: TopAppBarScrollBehavior,
  viewModel: AlbumViewModel = hiltViewModel(),
) {
  val context = LocalContext.current
  val menuState = LocalMenuState.current
  val database = LocalDatabase.current
  val haptic = LocalHapticFeedback.current
  val coroutineScope = rememberCoroutineScope()
  val playerConnection = LocalPlayerConnection.current ?: return

  val scope = rememberCoroutineScope()

  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()

  val playlistId by viewModel.playlistId.collectAsState()
  val albumWithSongs by viewModel.albumWithSongs.collectAsState()
  val otherVersions by viewModel.otherVersions.collectAsState()
  val releasesForYou by viewModel.releasesForYou.collectAsState()
  val description by viewModel.description.collectAsState()
  val descriptionRuns by viewModel.descriptionRuns.collectAsState()
  val hideExplicit by rememberPreference(key = HideExplicitKey, defaultValue = false)
  val dataSaverEnabled by
    rememberPreference(key = netmirror.music.iad1tya.constants.DataSaverEnabledKey, defaultValue = false)
  val hideVideoSongsPref by rememberPreference(key = HideVideoSongsKey, defaultValue = false)
  val hideVideoSongs = if (dataSaverEnabled) true else hideVideoSongsPref
  val albumCanvasEnabledPref by
    rememberPreference(key = AlbumCanvasEnabledKey, defaultValue = false)
  val albumCanvasEnabled = if (dataSaverEnabled) false else albumCanvasEnabledPref

  val canvasArtwork =
    rememberAlbumCanvas(
      albumTitle = albumWithSongs?.album?.title,
      artistName = albumWithSongs?.artists?.firstOrNull()?.name,
      firstSongTitle = albumWithSongs?.songs?.firstOrNull()?.song?.title
    )

  val filteredSongs =
    remember(albumWithSongs, hideExplicit, hideVideoSongs) {
      var songs = albumWithSongs?.songs ?: emptyList()
      if (hideExplicit) {
        songs = songs.filter { !it.song.explicit }
      }
      if (hideVideoSongs) {
        songs = songs.filter { !it.song.isVideo }
      }
      songs
    }

  var inSelectMode by rememberSaveable { mutableStateOf(false) }
  val selection =
    rememberSaveable(
      saver =
        listSaver<MutableList<String>, String>(
          save = { it.toList() },
          restore = { it.toMutableStateList() }
        )
    ) {
      mutableStateListOf()
    }
  val onExitSelectionMode = {
    inSelectMode = false
    selection.clear()
  }
  if (inSelectMode) {
    BackHandler(onBack = onExitSelectionMode)
  }

  LaunchedEffect(filteredSongs) {
    selection.fastForEachReversed { songId ->
      if (filteredSongs.find { it.id == songId } == null) {
        selection.remove(songId)
      }
    }
  }

  val downloadUtil = LocalDownloadUtil.current
  var downloadState by remember { mutableIntStateOf(Download.STATE_STOPPED) }

  LaunchedEffect(albumWithSongs) {
    val songs = albumWithSongs?.songs?.map { it.id }
    if (songs.isNullOrEmpty()) return@LaunchedEffect
    downloadUtil.downloads.collect { downloads ->
      downloadState =
        if (songs.all { downloads[it]?.state == Download.STATE_COMPLETED }) {
          Download.STATE_COMPLETED
        } else if (
          songs.all {
            downloads[it]?.state == Download.STATE_QUEUED ||
              downloads[it]?.state == Download.STATE_DOWNLOADING ||
              downloads[it]?.state == Download.STATE_COMPLETED
          }
        ) {
          Download.STATE_DOWNLOADING
        } else {
          Download.STATE_STOPPED
        }
    }
  }

  val hasExplicitContent = remember(albumWithSongs) { albumWithSongs?.album?.explicit == true }

  val lazyListState = rememberLazyListState()

  val transparentAppBar by remember {
    derivedStateOf {
      lazyListState.firstVisibleItemIndex == 0 && lazyListState.firstVisibleItemScrollOffset < 100
    }
  }

  LazyColumn(
    state = lazyListState,
    contentPadding = LocalPlayerAwareWindowInsets.current.asPaddingValues(),
  ) {
    val albumWithSongs = albumWithSongs
    if (albumWithSongs != null && albumWithSongs.songs.isNotEmpty()) {
      item(key = "album_header") {
        val systemBarsTopPadding = WindowInsets.systemBars.asPaddingValues().calculateTopPadding()
        val density = LocalDensity.current
        val headerOffset = with(density) { -(systemBarsTopPadding + AppBarHeight).roundToPx() }

        val configuration = LocalConfiguration.current
        val isTablet = configuration.screenWidthDp > 600
        val artSizeDp = if (isTablet) 300.dp else configuration.screenWidthDp.dp
        val artSizePx = with(density) { artSizeDp.toPx() }

        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
          Box(modifier = Modifier.matchParentSize().offset { IntOffset(x = 0, y = headerOffset) }) {
            Box(modifier = Modifier.fillMaxSize()) {
              AsyncImage(
                model = albumWithSongs.album.thumbnailUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )

              if (albumCanvasEnabled && canvasArtwork != null) {
                CanvasArtworkPlayer(
                  primaryUrl = canvasArtwork.animated,
                  fallbackUrl = canvasArtwork.videoUrl,
                  isPlaying = true,
                  modifier = Modifier.fillMaxSize()
                )
              }

              Box(
                modifier =
                  Modifier.fillMaxWidth()
                    .height(200.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                      brush =
                        Brush.verticalGradient(
                          colors = listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                        )
                    )
              )
            }
          }

          Column(
            modifier =
              Modifier.fillMaxWidth()
                .padding(top = with(density) { ((artSizePx / 1.2f) - 144).toDp() })
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Column(
              modifier =
                Modifier.fillMaxWidth().padding(horizontal = 32.dp).padding(bottom = 16.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              val albumInfoText = buildString {
                append(stringResource(R.string.album_text))
                if (albumWithSongs.album.year != null) {
                  append(" • ${albumWithSongs.album.year}")
                }
                append(" • ${albumWithSongs.songs.size} Tracks")
                val totalDuration = albumWithSongs.songs.sumOf { it.song.duration }
                val hours = totalDuration / 3600
                val minutes = (totalDuration % 3600) / 60
                if (hours > 0) {
                  append(" • ${hours}h ${minutes}m")
                } else {
                  append(" • ${minutes}m")
                }
              }

              if (albumWithSongs.artists.size == 1) {
                val artist = albumWithSongs.artists.first()
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Text(
                    text = albumWithSongs.album.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                  )

                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier =
                      Modifier.combinedClickable(
                        onClick = { navController.navigate("artist/${artist.id}") }
                      )
                  ) {
                    AsyncImage(
                      model = artist.thumbnailUrl,
                      contentDescription = null,
                      modifier = Modifier.size(28.dp).clip(CircleShape),
                      contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                      text = artist.name,
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Medium,
                      color = MaterialTheme.colorScheme.onSurface
                    )
                  }

                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(
                      text = albumInfoText,
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      textAlign = TextAlign.Center
                    )
                    if (hasExplicitContent) {
                      Text(
                        text = " • ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                      Icon(
                        painter = painterResource(R.drawable.explicit),
                        contentDescription = stringResource(R.string.explicit),
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                      Spacer(Modifier.width(4.dp))
                      Text(
                        text = stringResource(R.string.explicit),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                  }
                }
              } else {
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                  ) {
                    Text(
                      text = albumWithSongs.album.title,
                      style = MaterialTheme.typography.headlineMedium,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface,
                      maxLines = 2,
                      overflow = TextOverflow.Ellipsis,
                      modifier = Modifier.weight(1f, fill = false)
                    )
                  }

                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(
                      text = albumInfoText,
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      textAlign = TextAlign.Center
                    )
                    if (hasExplicitContent) {
                      Text(
                        text = " • ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                      Icon(
                        painter = painterResource(R.drawable.explicit),
                        contentDescription = stringResource(R.string.explicit),
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                      Spacer(Modifier.width(4.dp))
                      Text(
                        text = stringResource(R.string.explicit),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                  }
                }
              }

              Spacer(Modifier.height(24.dp))

              Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Surface(
                  onClick = { database.query { update(albumWithSongs.album.toggleLike()) } },
                  shape = CircleShape,
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier.size(48.dp)
                ) {
                  Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    HeartBurstIcon(
                      isLiked = albumWithSongs.album.bookmarkedAt != null,
                      iconSize = 22.dp
                    )
                  }
                }

                androidx.compose.material3.Button(
                  onClick = {
                    if (isPlaying && mediaMetadata?.album?.id == albumWithSongs.album.id) {
                      playerConnection.player.pause()
                    } else if (mediaMetadata?.album?.id == albumWithSongs.album.id) {
                      playerConnection.player.play()
                    } else {
                      playerConnection.service.getAutomix(playlistId)
                      playerConnection.playQueue(LocalAlbumRadio(albumWithSongs))
                    }
                  },
                  shape = CircleShape,
                  colors =
                    androidx.compose.material3.ButtonDefaults.buttonColors(
                      containerColor = MaterialTheme.colorScheme.primary,
                      contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                  contentPadding =
                    androidx.compose.foundation.layout.PaddingValues(
                      vertical = 12.dp,
                      horizontal = 16.dp
                    ),
                  modifier = Modifier.height(48.dp).weight(1.5f)
                ) {
                  Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      painter =
                        painterResource(
                          if (isPlaying && mediaMetadata?.album?.id == albumWithSongs.album.id)
                            R.drawable.pause
                          else R.drawable.play
                        ),
                      contentDescription = null,
                      modifier = Modifier.size(20.dp),
                      tint = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                      text =
                        if (isPlaying && mediaMetadata?.album?.id == albumWithSongs.album.id)
                          stringResource(R.string.pause)
                        else stringResource(R.string.play),
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                    )
                  }
                }

                Surface(
                  onClick = {
                    playerConnection.service.getAutomix(playlistId)
                    playerConnection.playQueue(
                      LocalAlbumRadio(albumWithSongs.copy(songs = albumWithSongs.songs.shuffled())),
                    )
                  },
                  shape = CircleShape,
                  color = MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier.size(48.dp)
                ) {
                  Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                      painter = painterResource(R.drawable.shuffle),
                      contentDescription = stringResource(R.string.shuffle_label),
                      modifier = Modifier.size(20.dp),
                      tint = MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }

            Spacer(Modifier.height(5.dp))

            val staticDescription =
              remember(albumWithSongs) {
                "${albumWithSongs.album.title} is an album by ${albumWithSongs.artists.joinToString { it.name }}${
                            if (albumWithSongs.album.year != null) ", released in ${albumWithSongs.album.year}" else ""
                        }. This collection features ${albumWithSongs.songs.size} tracks showcasing their musical artistry."
              }

            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
              Text(
                text = stringResource(R.string.about_album),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 8.dp)
              )

              ExpandableText(
                text = description ?: staticDescription,
                runs =
                  descriptionRuns?.map {
                    LinkSegment(text = it.text, url = it.navigationEndpoint?.urlEndpoint?.url)
                  },
                collapsedMaxLines = 3
              )
            }

            if (albumWithSongs.artists.size > 1) {
              Spacer(Modifier.height(16.dp))

              Text(
                text =
                  buildAnnotatedString {
                    append(stringResource(R.string.by_text))
                    append(" ")
                    albumWithSongs.artists.fastForEachIndexed { index, artist ->
                      val link =
                        LinkAnnotation.Clickable(artist.id) {
                          navController.navigate("artist/${artist.id}")
                        }
                      withLink(link) { append(artist.name) }
                      if (index != albumWithSongs.artists.lastIndex) {
                        append(", ")
                      }
                    }
                  },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                textAlign = TextAlign.Start
              )
            }
          }
        }
      }

      if (filteredSongs.isNotEmpty()) {
        item(key = "songs_title") {
          NavigationTitle(title = stringResource(R.string.songs), modifier = Modifier.animateItem())
        }

        itemsIndexed(
          items = filteredSongs,
          key = { _, song -> song.id },
        ) { index, song ->
          val onCheckedChange: (Boolean) -> Unit = {
            if (it) {
              selection.add(song.id)
            } else {
              selection.remove(song.id)
            }
          }

          SongListItem(
            song = song,
            isActive = song.id == mediaMetadata?.id,
            isPlaying = isPlaying,
            showInLibraryIcon = true,
            shape = listItemShape(index, filteredSongs.size),
            trailingContent = {
              if (inSelectMode) {
                Checkbox(checked = song.id in selection, onCheckedChange = onCheckedChange)
              } else {
                IconButton(
                  onClick = {
                    menuState.show {
                      SongMenu(
                        originalSong = song,
                        navController = navController,
                        onDismiss = menuState::dismiss,
                      )
                    }
                  },
                ) {
                  Icon(
                    painter = painterResource(R.drawable.more_vert),
                    contentDescription = null,
                  )
                }
              }
            },
            modifier =
              Modifier.fillMaxWidth()
                .animateItem()
                .combinedClickable(
                  onClick = {
                    if (inSelectMode) {
                      onCheckedChange(song.id !in selection)
                    } else if (song.id == mediaMetadata?.id) {
                      playerConnection.togglePlayPause()
                    } else {
                      playerConnection.service.getAutomix(playlistId)
                      playerConnection.playQueue(
                        LocalAlbumRadio(albumWithSongs, startIndex = index),
                      )
                    }
                  },
                  onLongClick = {
                    if (!inSelectMode) {
                      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                      inSelectMode = true
                      onCheckedChange(true)
                    }
                  },
                ),
          )
        }
      }

      if (otherVersions.isNotEmpty()) {
        item(key = "other_versions_title") {
          NavigationTitle(
            title = stringResource(R.string.other_versions),
            modifier = Modifier.animateItem()
          )
        }
        item(key = "other_versions_list") {
          LazyRow(
            contentPadding =
              WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).asPaddingValues(),
          ) {
            items(
              items = otherVersions.distinctBy { it.id },
              key = { it.id },
            ) { item ->
              YouTubeGridItem(
                item = item,
                isActive = mediaMetadata?.album?.id == item.id,
                isPlaying = isPlaying,
                coroutineScope = scope,
                modifier =
                  Modifier.combinedClickable(
                      onClick = { navController.navigate("album/${item.id}") },
                      onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuState.show {
                          YouTubeAlbumMenu(
                            albumItem = item,
                            navController = navController,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      },
                    )
                    .animateItem(),
              )
            }
          }
        }
      }

      if (releasesForYou.isNotEmpty()) {
        item(key = "releases_for_you_title") {
          NavigationTitle(
            title = stringResource(R.string.releases_for_you),
            modifier = Modifier.animateItem()
          )
        }
        item(key = "releases_for_you_list") {
          LazyRow(
            contentPadding =
              WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).asPaddingValues(),
          ) {
            items(
              items = releasesForYou.distinctBy { it.id },
              key = { it.id },
            ) { item ->
              YouTubeGridItem(
                item = item,
                isActive = mediaMetadata?.album?.id == item.id,
                isPlaying = isPlaying,
                coroutineScope = scope,
                modifier =
                  Modifier.combinedClickable(
                      onClick = { navController.navigate("album/${item.id}") },
                      onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuState.show {
                          YouTubeAlbumMenu(
                            albumItem = item,
                            navController = navController,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      },
                    )
                    .animateItem(),
              )
            }
          }
        }
      }

      item(key = "bottom_spacer") { Spacer(Modifier.height(50.dp)) }
    } else {
      item(key = "loading") {
        Box(
          modifier = Modifier.fillMaxWidth().padding(32.dp),
          contentAlignment = Alignment.Center
        ) {
          ContainedLoadingIndicator()
        }
      }
    }
  }

  TopAppBar(
    title = {
      if (inSelectMode) {
        Text(pluralStringResource(R.plurals.n_selected, selection.size, selection.size))
      }
    },
    navigationIcon = {
      if (inSelectMode) {
        IconButton(onClick = onExitSelectionMode) {
          Icon(
            painter = painterResource(R.drawable.close),
            contentDescription = null,
          )
        }
      } else {
        IconButton(
          onClick = { navController.navigateUp() },
          onLongClick = { navController.backToMain() },
          modifier =
            Modifier.background(
              androidx.compose.material3.MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
              CircleShape
            )
        ) {
          Icon(painter = painterResource(R.drawable.arrow_back_ios), contentDescription = null)
        }
      }
    },
    actions = {
      if (inSelectMode) {
        Checkbox(
          checked = selection.size == filteredSongs.size && selection.isNotEmpty(),
          onCheckedChange = {
            if (selection.size == filteredSongs.size) {
              selection.clear()
            } else {
              selection.clear()
              selection.addAll(filteredSongs.map { it.id })
            }
          }
        )
        IconButton(
          enabled = selection.isNotEmpty(),
          onClick = {
            menuState.show {
              SelectionSongMenu(
                songSelection =
                  selection.mapNotNull { songId -> filteredSongs.find { it.id == songId } },
                onDismiss = menuState::dismiss,
                clearAction = onExitSelectionMode
              )
            }
          }
        ) {
          Icon(painter = painterResource(R.drawable.more_vert), contentDescription = null)
        }
      } else {
        albumWithSongs?.let { albumWithSongs ->
          Row(
            modifier =
              Modifier.height(48.dp)
                .background(
                  color =
                    androidx.compose.material3.MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                  shape = CircleShape
                )
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            IconButton(
              onClick = {
                val intent =
                  android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(
                      android.content.Intent.EXTRA_TEXT,
                      "https://share.netmirror.fun/playlist?list=${albumWithSongs.album.playlistId}"
                    )
                  }
                context.startActivity(android.content.Intent.createChooser(intent, null))
              },
              modifier = Modifier.size(40.dp)
            ) {
              Icon(
                painter = painterResource(R.drawable.ios_share),
                contentDescription = stringResource(R.string.share),
                modifier = Modifier.size(20.dp)
              )
            }

            IconButton(
              onClick = {
                menuState.show {
                  AlbumMenu(
                    originalAlbum = Album(albumWithSongs.album, albumWithSongs.artists),
                    navController = navController,
                    onDismiss = menuState::dismiss,
                  )
                }
              },
              modifier = Modifier.size(40.dp)
            ) {
              Icon(
                painter = painterResource(R.drawable.more_vert),
                contentDescription = stringResource(R.string.more_options),
                modifier = Modifier.size(20.dp)
              )
            }
          }
        }
      }
    },
    colors =
      androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
        containerColor = Color.Transparent
      )
  )
}
