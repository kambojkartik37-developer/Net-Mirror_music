package netmirror.music.iad1tya.ui.component

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

/**
 * Stub CastButton for F-Droid builds. Does not render anything - Cast not available without GMS.
 */
@Composable
fun CastButton(
  modifier: Modifier = Modifier,
  tintColor: Color = MaterialTheme.colorScheme.onSurface,
  asMenuItem: Boolean = false,
) {
  // No-op: Cast not available in FOSS build
}
