@file:Suppress("UnstableApiUsage")

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)

    repositories {
        google()
        mavenCentral()
        maven { setUrl("https://jitpack.io") }
        maven { setUrl("https://maven.aliyun.com/repository/public") }
    }
}

// F-Droid doesn't support foojay-resolver plugin
// plugins {
//     id("org.gradle.toolchains.foojay-resolver-convention") version("1.0.0")
// }

rootProject.name = "netmirror"
include(
    ":app",
    ":innertube",
    ":paxsenixlyrics",
    ":kugou",
    ":betterlyrics",
    ":lrclib",
    ":simpmusic",
    ":youlyplus",
    ":shazamkit",
    ":artistvideo",
    ":canvas",
    ":netmirrorcanvas",
    ":applecanvas",
    ":unison",
    ":core",
    ":lyrics",
    ":playback",
    ":usbaudio",
    ":metadata",
    ":dsp-core",
    ":audio-dsp",
    ":domain"
)


// Use a local copy of BravePipe Extractor.
// We assume, that netmirror and BravePipe Extractor have the same parent directory.
// If this is not the case, please change the path in includeBuild().
//
// For this to work you also need to change the implementation in innertube/build.gradle.kts
// to one which does not specify a version.
// From:
//      implementation(libs.newpipe.extractor)
// To:
//      implementation("com.github.bravepipeproject:extractor")
// includeBuild("../BravePipeExtractor") {
//     dependencySubstitution {
//         substitute(module("com.github.bravepipeproject:extractor")).using(project(":extractor"))
//     }
// }
